import 'package:flutter/material.dart';
import '../../../core/routes/app_routes.dart';

class FlightSearchScreen extends StatefulWidget {
  const FlightSearchScreen({super.key});

  @override
  State<FlightSearchScreen> createState() => _FlightSearchScreenState();
}

class _FlightSearchScreenState extends State<FlightSearchScreen> {
  final _formKey = GlobalKey<FormState>();
  final _fromController = TextEditingController();
  final _toController = TextEditingController();
  DateTime _departureDate = DateTime.now().add(const Duration(days: 1));
  DateTime? _returnDate;
  int _passengers = 1;
  String _travelClass = 'Economy';
  bool _isRoundTrip = false;

  @override
  void dispose() {
    _fromController.dispose();
    _toController.dispose();
    super.dispose();
  }

  Future<void> _searchFlights() async {
    if (!_formKey.currentState!.validate()) return;

    final searchParams = {
      'from': _fromController.text,
      'to': _toController.text,
      'departureDate': _departureDate.toIso8601String(),
      'returnDate': _returnDate?.toIso8601String(),
      'passengers': _passengers,
      'travelClass': _travelClass,
      'isRoundTrip': _isRoundTrip,
    };

    Navigator.pushNamed(
      context,
      AppRoutes.flightResults,
      arguments: searchParams,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search Flights'),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: RadioListTile<bool>(
                              title: const Text('One Way'),
                              value: false,
                              groupValue: _isRoundTrip,
                              onChanged: (value) => setState(() => _isRoundTrip = value!),
                            ),
                          ),
                          Expanded(
                            child: RadioListTile<bool>(
                              title: const Text('Round Trip'),
                              value: true,
                              groupValue: _isRoundTrip,
                              onChanged: (value) => setState(() => _isRoundTrip = value!),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _fromController,
                        decoration: const InputDecoration(
                          labelText: 'From',
                          prefixIcon: Icon(Icons.flight_takeoff),
                          hintText: 'Departure city',
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter departure city';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _toController,
                        decoration: const InputDecoration(
                          labelText: 'To',
                          prefixIcon: Icon(Icons.flight_land),
                          hintText: 'Destination city',
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter destination city';
                          }
                          return null;
                        },
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(Icons.calendar_today),
                        title: const Text('Departure Date'),
                        subtitle: Text(_departureDate.toString().split(' ')[0]),
                        onTap: () async {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: _departureDate,
                            firstDate: DateTime.now(),
                            lastDate: DateTime.now().add(const Duration(days: 365)),
                          );
                          if (date != null) {
                            setState(() => _departureDate = date);
                          }
                        },
                      ),
                      if (_isRoundTrip) ...[
                        const Divider(),
                        ListTile(
                          leading: const Icon(Icons.calendar_today),
                          title: const Text('Return Date'),
                          subtitle: Text(_returnDate?.toString().split(' ')[0] ?? 'Select date'),
                          onTap: () async {
                            final date = await showDatePicker(
                              context: context,
                              initialDate: _returnDate ?? _departureDate.add(const Duration(days: 1)),
                              firstDate: _departureDate,
                              lastDate: DateTime.now().add(const Duration(days: 365)),
                            );
                            if (date != null) {
                              setState(() => _returnDate = date);
                            }
                          },
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(Icons.people),
                        title: const Text('Passengers'),
                        subtitle: Text('$_passengers passenger${_passengers > 1 ? 's' : ''}'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              onPressed: _passengers > 1 ? () => setState(() => _passengers--) : null,
                              icon: const Icon(Icons.remove),
                            ),
                            Text('$_passengers'),
                            IconButton(
                              onPressed: _passengers < 9 ? () => setState(() => _passengers++) : null,
                              icon: const Icon(Icons.add),
                            ),
                          ],
                        ),
                      ),
                      const Divider(),
                      ListTile(
                        leading: const Icon(Icons.airline_seat_recline_normal),
                        title: const Text('Travel Class'),
                        subtitle: Text(_travelClass),
                        onTap: () async {
                          final result = await showDialog<String>(
                            context: context,
                            builder: (context) => SimpleDialog(
                              title: const Text('Select Travel Class'),
                              children: ['Economy', 'Premium Economy', 'Business', 'First']
                                  .map((cls) => SimpleDialogOption(
                                        onPressed: () => Navigator.pop(context, cls),
                                        child: Text(cls),
                                      ))
                                  .toList(),
                            ),
                          );
                          if (result != null) {
                            setState(() => _travelClass = result);
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _searchFlights,
                child: const Text('Search Flights'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

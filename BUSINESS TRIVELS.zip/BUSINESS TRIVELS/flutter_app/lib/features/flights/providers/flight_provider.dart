import 'package:flutter/foundation.dart';
import '../../../core/services/api_service.dart';
import '../models/flight.dart';

class FlightProvider extends ChangeNotifier {
  final ApiService _apiService;
  
  FlightProvider(this._apiService);

  List<Flight> _flights = [];
  bool _isLoading = false;
  String? _errorMessage;
  Map<String, dynamic> _searchParams = {};

  List<Flight> get flights => _flights;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String? get error => _errorMessage;
  Map<String, dynamic> get searchParams => _searchParams;

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String? error) {
    _errorMessage = error;
    notifyListeners();
  }

  Future<void> searchFlights(Map<String, dynamic> params) async {
    try {
      _setLoading(true);
      _setError(null);
      
      _searchParams = params;

      // Mock data for now - replace with actual API call
      await Future.delayed(const Duration(seconds: 2));
      
      _flights = [
        Flight(
          id: 'FL001',
          airline: 'American Airlines',
          flightNumber: 'AA123',
          from: params['from'] ?? 'Los Angeles',
          to: params['to'] ?? 'New York',
          departureTime: '10:30 AM',
          arrivalTime: '6:45 PM',
          duration: '5h 15m',
          price: 450.0,
          travelClass: params['travelClass'] ?? 'Economy',
          stops: 0,
          availableSeats: 12,
        ),
        Flight(
          id: 'FL002',
          airline: 'Delta Airlines',
          flightNumber: 'DL456',
          from: params['from'] ?? 'Los Angeles',
          to: params['to'] ?? 'New York',
          departureTime: '2:15 PM',
          arrivalTime: '10:30 PM',
          duration: '5h 15m',
          price: 380.0,
          travelClass: params['travelClass'] ?? 'Economy',
          stops: 1,
          availableSeats: 8,
        ),
        Flight(
          id: 'FL003',
          airline: 'United Airlines',
          flightNumber: 'UA789',
          from: params['from'] ?? 'Los Angeles',
          to: params['to'] ?? 'New York',
          departureTime: '6:00 PM',
          arrivalTime: '2:15 AM+1',
          duration: '5h 15m',
          price: 520.0,
          travelClass: params['travelClass'] ?? 'Economy',
          stops: 0,
          availableSeats: 15,
        ),
      ];
    } catch (e) {
      _setError(e.toString());
      _flights = [];
    } finally {
      _setLoading(false);
    }
  }

  Future<Map<String, dynamic>?> getFlightDetails(String flightId) async {
    try {
      _setLoading(true);
      _setError(null);
      
      final result = await _apiService.getFlightDetails(flightId);
      return result['data'];
    } catch (e) {
      _setError(e.toString());
      return null;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> bookFlight({
    required String flightId,
    required Map<String, dynamic> passengerInfo,
    required Map<String, dynamic> paymentInfo,
  }) async {
    try {
      _setLoading(true);
      _setError(null);
      
      await _apiService.bookFlight(
        flightId: flightId,
        passengerInfo: passengerInfo,
        paymentInfo: paymentInfo,
      );
      
      return true;
    } catch (e) {
      _setError(e.toString());
      return false;
    } finally {
      _setLoading(false);
    }
  }

  void clearError() {
    _setError(null);
  }

  void clearFlights() {
    _flights = [];
    _searchParams = {};
    notifyListeners();
  }

  void sortFlightsByPrice({bool ascending = true}) {
    _flights.sort((a, b) => ascending 
        ? a.price.compareTo(b.price) 
        : b.price.compareTo(a.price));
    notifyListeners();
  }

  void sortFlightsByDuration() {
    _flights.sort((a, b) {
      // Extract hours and minutes from duration string (e.g., "5h 15m")
      final aDuration = _parseDuration(a.duration);
      final bDuration = _parseDuration(b.duration);
      return aDuration.compareTo(bDuration);
    });
    notifyListeners();
  }

  void filterDirectFlights() {
    _flights = _flights.where((flight) => flight.stops == 0).toList();
    notifyListeners();
  }

  int _parseDuration(String duration) {
    final regex = RegExp(r'(\d+)h\s*(\d+)m');
    final match = regex.firstMatch(duration);
    if (match != null) {
      final hours = int.parse(match.group(1) ?? '0');
      final minutes = int.parse(match.group(2) ?? '0');
      return hours * 60 + minutes;
    }
    return 0;
  }
}

enum BookingType { flight, hotel, package }

enum BookingStatus { pending, confirmed, cancelled, completed }

class Booking {
  final String id;
  final String title;
  final BookingType type;
  final BookingStatus status;
  final DateTime bookingDate;
  final double totalAmount;
  final Map<String, dynamic> details;

  Booking({
    required this.id,
    required this.title,
    required this.type,
    required this.status,
    required this.bookingDate,
    required this.totalAmount,
    required this.details,
  });

  factory Booking.fromJson(Map<String, dynamic> json) {
    return Booking(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      type: BookingType.values.firstWhere(
        (e) => e.toString() == 'BookingType.${json['type']}',
        orElse: () => BookingType.flight,
      ),
      status: BookingStatus.values.firstWhere(
        (e) => e.toString() == 'BookingStatus.${json['status']}',
        orElse: () => BookingStatus.pending,
      ),
      bookingDate: DateTime.parse(json['bookingDate'] ?? DateTime.now().toIso8601String()),
      totalAmount: (json['totalAmount'] ?? 0).toDouble(),
      details: Map<String, dynamic>.from(json['details'] ?? {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'type': type.toString().split('.').last,
      'status': status.toString().split('.').last,
      'bookingDate': bookingDate.toIso8601String(),
      'totalAmount': totalAmount,
      'details': details,
    };
  }
}

import 'package:flutter/foundation.dart';
import 'dart:developer' as developer;
import '../../../core/services/api_service.dart';
import '../models/booking.dart';
import '../../flights/models/flight.dart';
import '../../hotels/models/hotel.dart';

class BookingProvider extends ChangeNotifier {
  final ApiService _apiService;
  
  List<Booking> _bookings = [];
  bool _isLoading = false;
  String? _error;

  BookingProvider(this._apiService);

  List<Booking> get bookings => _bookings;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> loadBookings() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // Use API service to fetch bookings - using getUserBookings method
      // For now, use mock user ID until auth is implemented
      try {
        final response = await _apiService.getUserBookings('mock_user_id');
        // Parse response data when backend is ready
        if (response['success'] == true && response['data'] != null) {
          // _bookings = (response['data'] as List).map((json) => Booking.fromJson(json)).toList();
          // For now, log the response and use mock data
          developer.log('API Response received: ${response.keys}', name: 'BookingProvider');
        }
      } catch (apiError) {
        // If API call fails, fall back to mock data
        await Future.delayed(const Duration(seconds: 1));
      }
      
      _bookings = [
        Booking(
          id: 'BK001',
          title: 'Flight to New York',
          type: BookingType.flight,
          status: BookingStatus.confirmed,
          bookingDate: DateTime.now().subtract(const Duration(days: 2)),
          totalAmount: 450.00,
          details: {
            'airline': 'American Airlines',
            'flightNumber': 'AA123',
            'from': 'Los Angeles',
            'to': 'New York',
            'departureTime': '10:30 AM',
            'arrivalTime': '6:45 PM',
          },
        ),
        Booking(
          id: 'BK002',
          title: 'Hotel Reservation - Grand Plaza',
          type: BookingType.hotel,
          status: BookingStatus.pending,
          bookingDate: DateTime.now().subtract(const Duration(days: 1)),
          totalAmount: 320.00,
          details: {
            'hotelName': 'Grand Plaza Hotel',
            'checkIn': '2024-01-15',
            'checkOut': '2024-01-18',
            'guests': 2,
            'rooms': 1,
          },
        ),
      ];
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<Booking> createFlightBooking({
    required Flight flight,
    required Map<String, String> passengerDetails,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // Mock booking creation - replace with actual API call
      await Future.delayed(const Duration(seconds: 2));
      
      final booking = Booking(
        id: 'BK${DateTime.now().millisecondsSinceEpoch}',
        title: 'Flight to ${flight.to}',
        type: BookingType.flight,
        status: BookingStatus.confirmed,
        bookingDate: DateTime.now(),
        totalAmount: flight.price * 1.15, // Including taxes
        details: {
          'airline': flight.airline,
          'flightNumber': flight.flightNumber,
          'from': flight.from,
          'to': flight.to,
          'departureTime': flight.departureTime,
          'arrivalTime': flight.arrivalTime,
          'passengerName': '${passengerDetails['firstName']} ${passengerDetails['lastName']}',
          'email': passengerDetails['email'] ?? '',
          'phone': passengerDetails['phone'] ?? '',
        },
      );

      _bookings.insert(0, booking);
      notifyListeners();
      
      return booking;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<Booking> createHotelBooking({
    required Hotel hotel,
    required DateTime checkInDate,
    required DateTime checkOutDate,
    required int guests,
    required int rooms,
    required Map<String, String> guestDetails,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // Mock booking creation - replace with actual API call
      await Future.delayed(const Duration(seconds: 2));
      
      final nights = checkOutDate.difference(checkInDate).inDays;
      final subtotal = hotel.pricePerNight * nights * rooms;
      final total = subtotal * 1.12; // Including taxes

      final booking = Booking(
        id: 'BK${DateTime.now().millisecondsSinceEpoch}',
        title: 'Hotel - ${hotel.name}',
        type: BookingType.hotel,
        status: BookingStatus.confirmed,
        bookingDate: DateTime.now(),
        totalAmount: total,
        details: {
          'hotelName': hotel.name,
          'address': hotel.address,
          'checkIn': checkInDate.toString().split(' ')[0],
          'checkOut': checkOutDate.toString().split(' ')[0],
          'nights': nights,
          'guests': guests,
          'rooms': rooms,
          'guestName': '${guestDetails['firstName']} ${guestDetails['lastName']}',
          'email': guestDetails['email'] ?? '',
          'phone': guestDetails['phone'] ?? '',
        },
      );

      _bookings.insert(0, booking);
      notifyListeners();
      
      return booking;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> cancelBooking(String bookingId) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // Mock cancellation - replace with actual API call
      await Future.delayed(const Duration(seconds: 1));
      
      final index = _bookings.indexWhere((booking) => booking.id == bookingId);
      if (index != -1) {
        final booking = _bookings[index];
        final cancelledBooking = Booking(
          id: booking.id,
          title: booking.title,
          type: booking.type,
          status: BookingStatus.cancelled,
          bookingDate: booking.bookingDate,
          totalAmount: booking.totalAmount,
          details: booking.details,
        );
        _bookings[index] = cancelledBooking;
      }
    } catch (e) {
      _error = e.toString();
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}

import 'package:flutter/foundation.dart';
import '../../../core/services/api_service.dart';
import '../models/package.dart';

class PackageProvider extends ChangeNotifier {
  final ApiService _apiService;
  
  PackageProvider(this._apiService);

  List<TravelPackage> _packages = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<TravelPackage> get packages => _packages;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String? get error => _errorMessage;

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String? error) {
    _errorMessage = error;
    notifyListeners();
  }

  Future<void> loadPackages() async {
    try {
      _setLoading(true);
      _setError(null);

      // Use API service to search packages
      await _apiService.searchPackages();
      
      // Mock data for now - replace with actual API call
      await Future.delayed(const Duration(seconds: 2));
      
      _packages = [
        TravelPackage(
          id: 'PK001',
          name: 'Paris Romance Package',
          destination: 'Paris, France',
          description: 'Experience the city of love with this romantic getaway including luxury accommodations, fine dining, and guided tours.',
          duration: 7,
          price: 2500.0,
          originalPrice: 3000.0,
          includes: ['Flight', 'Hotel', 'Breakfast', 'City Tour', 'Seine Cruise'],
          imageUrl: null,
        ),
        TravelPackage(
          id: 'PK002',
          name: 'Tokyo Adventure',
          destination: 'Tokyo, Japan',
          description: 'Discover the vibrant culture of Japan with visits to temples, modern districts, and authentic cuisine experiences.',
          duration: 10,
          price: 3200.0,
          originalPrice: 3800.0,
          includes: ['Flight', 'Hotel', 'JR Pass', 'Cultural Tours', 'Traditional Meals'],
          imageUrl: null,
        ),
        TravelPackage(
          id: 'PK003',
          name: 'Bali Tropical Escape',
          destination: 'Bali, Indonesia',
          description: 'Relax in paradise with beautiful beaches, spa treatments, and cultural experiences in the Island of Gods.',
          duration: 5,
          price: 1800.0,
          originalPrice: 2200.0,
          includes: ['Flight', 'Resort', 'Spa Treatment', 'Beach Activities', 'Temple Tours'],
          imageUrl: null,
        ),
      ];
    } catch (e) {
      _setError(e.toString());
      _packages = [];
    } finally {
      _setLoading(false);
    }
  }

  void clearError() {
    _setError(null);
  }

  void clearPackages() {
    _packages = [];
    notifyListeners();
  }
}

class TravelPackage {
  final String id;
  final String name;
  final String destination;
  final String description;
  final int duration;
  final double price;
  final double originalPrice;
  final List<String> includes;
  final String? imageUrl;

  TravelPackage({
    required this.id,
    required this.name,
    required this.destination,
    required this.description,
    required this.duration,
    required this.price,
    required this.originalPrice,
    required this.includes,
    this.imageUrl,
  });

  factory TravelPackage.fromJson(Map<String, dynamic> json) {
    return TravelPackage(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      destination: json['destination'] ?? '',
      description: json['description'] ?? '',
      duration: json['duration'] ?? 0,
      price: (json['price'] ?? 0).toDouble(),
      originalPrice: (json['originalPrice'] ?? 0).toDouble(),
      includes: List<String>.from(json['includes'] ?? []),
      imageUrl: json['imageUrl'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'destination': destination,
      'description': description,
      'duration': duration,
      'price': price,
      'originalPrice': originalPrice,
      'includes': includes,
      'imageUrl': imageUrl,
    };
  }
}

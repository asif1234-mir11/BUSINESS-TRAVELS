import 'package:flutter/foundation.dart';
import '../../../core/services/api_service.dart';
import '../models/hotel.dart';

class HotelProvider extends ChangeNotifier {
  final ApiService _apiService;
  
  HotelProvider(this._apiService);

  List<Hotel> _hotels = [];
  bool _isLoading = false;
  String? _errorMessage;
  Map<String, dynamic> _searchParams = {};

  List<Hotel> get hotels => _hotels;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String? get error => _errorMessage;
  Map<String, dynamic> get searchParams => _searchParams;

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String? error) {
    _errorMessage = error;
    notifyListeners();
  }

  Future<void> searchHotels(Map<String, dynamic> params) async {
    try {
      _setLoading(true);
      _setError(null);
      
      _searchParams = params;

      // Mock data for now - replace with actual API call
      await Future.delayed(const Duration(seconds: 2));
      
      _hotels = [
        Hotel(
          id: 'HT001',
          name: 'Grand Plaza Hotel',
          address: '123 Main St, ${params['destination'] ?? 'New York'}',
          description: 'Luxury hotel in the heart of the city with modern amenities and exceptional service.',
          rating: 5,
          pricePerNight: 250.0,
          amenities: ['WiFi', 'Pool', 'Gym', 'Restaurant', 'Spa'],
          imageUrl: null,
        ),
        Hotel(
          id: 'HT002',
          name: 'City Center Inn',
          address: '456 Oak Ave, ${params['destination'] ?? 'New York'}',
          description: 'Comfortable and affordable accommodation with great location.',
          rating: 4,
          pricePerNight: 150.0,
          amenities: ['WiFi', 'Breakfast', 'Parking'],
          imageUrl: null,
        ),
        Hotel(
          id: 'HT003',
          name: 'Boutique Suites',
          address: '789 Pine St, ${params['destination'] ?? 'New York'}',
          description: 'Elegant boutique hotel with personalized service and unique design.',
          rating: 4,
          pricePerNight: 320.0,
          amenities: ['WiFi', 'Concierge', 'Room Service', 'Bar'],
          imageUrl: null,
        ),
      ];
    } catch (e) {
      _setError(e.toString());
      _hotels = [];
    } finally {
      _setLoading(false);
    }
  }

  Future<Map<String, dynamic>?> getHotelDetails(String hotelId) async {
    try {
      _setLoading(true);
      _setError(null);
      
      final result = await _apiService.getHotelDetails(hotelId);
      return result['data'];
    } catch (e) {
      _setError(e.toString());
      return null;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> bookHotel({
    required String hotelId,
    required Map<String, dynamic> guestInfo,
    required Map<String, dynamic> roomDetails,
    required Map<String, dynamic> paymentInfo,
  }) async {
    try {
      _setLoading(true);
      _setError(null);
      
      await _apiService.bookHotel(
        hotelId: hotelId,
        guestInfo: guestInfo,
        roomDetails: roomDetails,
        paymentInfo: paymentInfo,
      );
      
      return true;
    } catch (e) {
      _setError(e.toString());
      return false;
    } finally {
      _setLoading(false);
    }
  }

  void clearError() {
    _setError(null);
  }

  void clearHotels() {
    _hotels = [];
    _searchParams = {};
    notifyListeners();
  }

  void sortHotelsByPrice({bool ascending = true}) {
    _hotels.sort((a, b) => ascending 
        ? a.pricePerNight.compareTo(b.pricePerNight) 
        : b.pricePerNight.compareTo(a.pricePerNight));
    notifyListeners();
  }

  void sortHotelsByRating() {
    _hotels.sort((a, b) => b.rating.compareTo(a.rating));
    notifyListeners();
  }

  void filterByRating(int minRating) {
    _hotels = _hotels.where((hotel) => hotel.rating >= minRating).toList();
    notifyListeners();
  }
}

class Hotel {
  final String id;
  final String name;
  final String address;
  final String description;
  final int rating;
  final double pricePerNight;
  final List<String> amenities;
  final String? imageUrl;

  Hotel({
    required this.id,
    required this.name,
    required this.address,
    required this.description,
    required this.rating,
    required this.pricePerNight,
    required this.amenities,
    this.imageUrl,
  });

  factory Hotel.fromJson(Map<String, dynamic> json) {
    return Hotel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      address: json['address'] ?? '',
      description: json['description'] ?? '',
      rating: json['rating'] ?? 0,
      pricePerNight: (json['pricePerNight'] ?? 0).toDouble(),
      amenities: List<String>.from(json['amenities'] ?? []),
      imageUrl: json['imageUrl'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'address': address,
      'description': description,
      'rating': rating,
      'pricePerNight': pricePerNight,
      'amenities': amenities,
      'imageUrl': imageUrl,
    };
  }
}

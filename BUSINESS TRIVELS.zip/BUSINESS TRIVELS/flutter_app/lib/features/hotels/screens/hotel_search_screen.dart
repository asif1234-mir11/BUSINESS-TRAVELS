import 'package:flutter/material.dart';
import '../../../core/routes/app_routes.dart';

class HotelSearchScreen extends StatefulWidget {
  const HotelSearchScreen({super.key});

  @override
  State<HotelSearchScreen> createState() => _HotelSearchScreenState();
}

class _HotelSearchScreenState extends State<HotelSearchScreen> {
  final _formKey = GlobalKey<FormState>();
  final _destinationController = TextEditingController();
  DateTime _checkInDate = DateTime.now().add(const Duration(days: 1));
  DateTime _checkOutDate = DateTime.now().add(const Duration(days: 2));
  int _guests = 1;
  int _rooms = 1;

  @override
  void dispose() {
    _destinationController.dispose();
    super.dispose();
  }

  Future<void> _searchHotels() async {
    if (!_formKey.currentState!.validate()) return;

    final searchParams = {
      'destination': _destinationController.text,
      'checkInDate': _checkInDate.toIso8601String(),
      'checkOutDate': _checkOutDate.toIso8601String(),
      'guests': _guests,
      'rooms': _rooms,
    };

    Navigator.pushNamed(
      context,
      AppRoutes.hotelResults,
      arguments: searchParams,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search Hotels'),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: TextFormField(
                    controller: _destinationController,
                    decoration: const InputDecoration(
                      labelText: 'Destination',
                      prefixIcon: Icon(Icons.location_on),
                      hintText: 'City, hotel name, or landmark',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a destination';
                      }
                      return null;
                    },
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(Icons.calendar_today),
                        title: const Text('Check-in Date'),
                        subtitle: Text(_checkInDate.toString().split(' ')[0]),
                        onTap: () async {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: _checkInDate,
                            firstDate: DateTime.now(),
                            lastDate: DateTime.now().add(const Duration(days: 365)),
                          );
                          if (date != null) {
                            setState(() {
                              _checkInDate = date;
                              if (_checkOutDate.isBefore(_checkInDate.add(const Duration(days: 1)))) {
                                _checkOutDate = _checkInDate.add(const Duration(days: 1));
                              }
                            });
                          }
                        },
                      ),
                      const Divider(),
                      ListTile(
                        leading: const Icon(Icons.calendar_today),
                        title: const Text('Check-out Date'),
                        subtitle: Text(_checkOutDate.toString().split(' ')[0]),
                        onTap: () async {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: _checkOutDate,
                            firstDate: _checkInDate.add(const Duration(days: 1)),
                            lastDate: DateTime.now().add(const Duration(days: 365)),
                          );
                          if (date != null) {
                            setState(() => _checkOutDate = date);
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(Icons.people),
                        title: const Text('Guests'),
                        subtitle: Text('$_guests guest${_guests > 1 ? 's' : ''}'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              onPressed: _guests > 1 ? () => setState(() => _guests--) : null,
                              icon: const Icon(Icons.remove),
                            ),
                            Text('$_guests'),
                            IconButton(
                              onPressed: _guests < 10 ? () => setState(() => _guests++) : null,
                              icon: const Icon(Icons.add),
                            ),
                          ],
                        ),
                      ),
                      const Divider(),
                      ListTile(
                        leading: const Icon(Icons.hotel),
                        title: const Text('Rooms'),
                        subtitle: Text('$_rooms room${_rooms > 1 ? 's' : ''}'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              onPressed: _rooms > 1 ? () => setState(() => _rooms--) : null,
                              icon: const Icon(Icons.remove),
                            ),
                            Text('$_rooms'),
                            IconButton(
                              onPressed: _rooms < 5 ? () => setState(() => _rooms++) : null,
                              icon: const Icon(Icons.add),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _searchHotels,
                child: const Text('Search Hotels'),
              ),
              const SizedBox(height: 16),
              Text(
                'Stay duration: ${_checkOutDate.difference(_checkInDate).inDays} night${_checkOutDate.difference(_checkInDate).inDays > 1 ? 's' : ''}',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.grey[600],
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

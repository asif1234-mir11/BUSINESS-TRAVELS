import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:firebase_core/firebase_core.dart';

import 'core/theme/app_theme.dart';
import 'core/routes/app_routes.dart';
import 'core/services/api_service.dart';
import 'core/services/auth_service.dart';
import 'core/services/storage_service.dart';
import 'features/auth/providers/auth_provider.dart';
import 'features/flights/providers/flight_provider.dart';
import 'features/hotels/providers/hotel_provider.dart';
import 'features/packages/providers/package_provider.dart';
import 'features/bookings/providers/booking_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase
  await Firebase.initializeApp();
  
  // Initialize Hive
  await Hive.initFlutter();
  
  // Initialize services
  await StorageService.init();
  
  runApp(const BusinessTravelsApp());
}

class BusinessTravelsApp extends StatelessWidget {
  const BusinessTravelsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<ApiService>(create: (_) => ApiService()),
        Provider<AuthService>(create: (_) => AuthService()),
        Provider<StorageService>(create: (_) => StorageService()),
        
        ChangeNotifierProxyProvider<AuthService, AuthProvider>(
          create: (context) => AuthProvider(context.read<AuthService>()),
          update: (context, authService, previous) => 
              previous ?? AuthProvider(authService),
        ),
        
        ChangeNotifierProxyProvider<ApiService, FlightProvider>(
          create: (context) => FlightProvider(context.read<ApiService>()),
          update: (context, apiService, previous) => 
              previous ?? FlightProvider(apiService),
        ),
        
        ChangeNotifierProxyProvider<ApiService, HotelProvider>(
          create: (context) => HotelProvider(context.read<ApiService>()),
          update: (context, apiService, previous) => 
              previous ?? HotelProvider(apiService),
        ),
        
        ChangeNotifierProxyProvider<ApiService, PackageProvider>(
          create: (context) => PackageProvider(context.read<ApiService>()),
          update: (context, apiService, previous) => 
              previous ?? PackageProvider(apiService),
        ),
        
        ChangeNotifierProxyProvider<ApiService, BookingProvider>(
          create: (context) => BookingProvider(context.read<ApiService>()),
          update: (context, apiService, previous) => 
              previous ?? BookingProvider(apiService),
        ),
      ],
      child: MaterialApp(
        title: 'Business Travels',
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        initialRoute: AppRoutes.splash,
        onGenerateRoute: AppRoutes.generateRoute,
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}

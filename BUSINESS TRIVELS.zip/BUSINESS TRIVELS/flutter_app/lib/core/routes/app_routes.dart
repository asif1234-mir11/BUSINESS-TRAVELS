import 'package:flutter/material.dart';
import '../../features/splash/screens/splash_screen.dart';
import '../../features/auth/screens/login_screen.dart';
import '../../features/auth/screens/register_screen.dart';
import '../../features/home/screens/home_screen.dart';
import '../../features/flights/screens/flight_search_screen.dart';
import '../../features/flights/screens/flight_results_screen.dart';
import '../../features/flights/screens/flight_booking_screen.dart';
import '../../features/hotels/screens/hotel_search_screen.dart';
import '../../features/hotels/screens/hotel_results_screen.dart';
import '../../features/hotels/screens/hotel_booking_screen.dart';
import '../../features/packages/screens/package_screen.dart';
import '../../features/bookings/screens/booking_list_screen.dart';
import '../../features/profile/screens/profile_screen.dart';

class AppRoutes {
  static const String splash = '/';
  static const String login = '/login';
  static const String register = '/register';
  static const String home = '/home';
  static const String flightSearch = '/flight-search';
  static const String flightResults = '/flight-results';
  static const String flightBooking = '/flight-booking';
  static const String hotelSearch = '/hotel-search';
  static const String hotelResults = '/hotel-results';
  static const String hotelBooking = '/hotel-booking';
  static const String packages = '/packages';
  static const String bookings = '/bookings';
  static const String profile = '/profile';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case splash:
        return MaterialPageRoute(builder: (_) => const SplashScreen());
      case login:
        return MaterialPageRoute(builder: (_) => const LoginScreen());
      case register:
        return MaterialPageRoute(builder: (_) => const RegisterScreen());
      case home:
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case flightSearch:
        return MaterialPageRoute(builder: (_) => const FlightSearchScreen());
      case flightResults:
        final args = settings.arguments as Map<String, dynamic>?;
        return MaterialPageRoute(
          builder: (_) => FlightResultsScreen(searchParams: args ?? {}),
        );
      case flightBooking:
        final args = settings.arguments as Map<String, dynamic>?;
        return MaterialPageRoute(
          builder: (_) => FlightBookingScreen(flight: args?['flight']),
        );
      case hotelSearch:
        return MaterialPageRoute(builder: (_) => const HotelSearchScreen());
      case hotelResults:
        final args = settings.arguments as Map<String, dynamic>?;
        return MaterialPageRoute(
          builder: (_) => HotelResultsScreen(searchParams: args ?? {}),
        );
      case hotelBooking:
        final args = settings.arguments as Map<String, dynamic>?;
        return MaterialPageRoute(
          builder: (_) => HotelBookingScreen(hotel: args?['hotel']),
        );
      case packages:
        return MaterialPageRoute(builder: (_) => const PackageScreen());
      case bookings:
        return MaterialPageRoute(builder: (_) => const BookingListScreen());
      case profile:
        return MaterialPageRoute(builder: (_) => const ProfileScreen());
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: Text('No route defined for ${settings.name}'),
            ),
          ),
        );
    }
  }
}

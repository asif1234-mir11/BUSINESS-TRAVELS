import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://localhost:3000/api';
  
  final http.Client _client = http.Client();
  
  // Headers for API requests
  Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  // Flight API calls
  Future<Map<String, dynamic>> searchFlights({
    required String from,
    required String to,
    required String departDate,
    String? returnDate,
    int passengers = 1,
    String flightClass = 'Economy',
  }) async {
    final queryParams = {
      'from': from,
      'to': to,
      'departDate': departDate,
      if (returnDate != null) 'returnDate': returnDate,
      'passengers': passengers.toString(),
      'class': flightClass,
    };

    final uri = Uri.parse('$baseUrl/flights/search')
        .replace(queryParameters: queryParams);

    try {
      final response = await _client.get(uri, headers: _headers);
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Failed to search flights: $e');
    }
  }

  Future<Map<String, dynamic>> getFlightDetails(String flightId) async {
    try {
      final response = await _client.get(
        Uri.parse('$baseUrl/flights/$flightId'),
        headers: _headers,
      );
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Failed to get flight details: $e');
    }
  }

  Future<Map<String, dynamic>> bookFlight({
    required String flightId,
    required Map<String, dynamic> passengerInfo,
    required Map<String, dynamic> paymentInfo,
  }) async {
    final body = {
      'flightId': flightId,
      'passengerInfo': passengerInfo,
      'paymentInfo': paymentInfo,
    };

    try {
      final response = await _client.post(
        Uri.parse('$baseUrl/flights/book'),
        headers: _headers,
        body: json.encode(body),
      );
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Failed to book flight: $e');
    }
  }

  // Hotel API calls
  Future<Map<String, dynamic>> searchHotels({
    required String destination,
    required String checkinDate,
    required String checkoutDate,
    int rooms = 1,
    int guests = 2,
  }) async {
    final queryParams = {
      'destination': destination,
      'checkinDate': checkinDate,
      'checkoutDate': checkoutDate,
      'rooms': rooms.toString(),
      'guests': guests.toString(),
    };

    final uri = Uri.parse('$baseUrl/hotels/search')
        .replace(queryParameters: queryParams);

    try {
      final response = await _client.get(uri, headers: _headers);
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Failed to search hotels: $e');
    }
  }

  Future<Map<String, dynamic>> getHotelDetails(String hotelId) async {
    try {
      final response = await _client.get(
        Uri.parse('$baseUrl/hotels/$hotelId'),
        headers: _headers,
      );
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Failed to get hotel details: $e');
    }
  }

  Future<Map<String, dynamic>> bookHotel({
    required String hotelId,
    required Map<String, dynamic> guestInfo,
    required Map<String, dynamic> roomDetails,
    required Map<String, dynamic> paymentInfo,
  }) async {
    final body = {
      'hotelId': hotelId,
      'guestInfo': guestInfo,
      'roomDetails': roomDetails,
      'paymentInfo': paymentInfo,
    };

    try {
      final response = await _client.post(
        Uri.parse('$baseUrl/hotels/book'),
        headers: _headers,
        body: json.encode(body),
      );
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Failed to book hotel: $e');
    }
  }

  // Package API calls
  Future<Map<String, dynamic>> searchPackages({
    String? destination,
    String? duration,
    String? budget,
  }) async {
    final queryParams = <String, String>{};
    if (destination != null) queryParams['destination'] = destination;
    if (duration != null) queryParams['duration'] = duration;
    if (budget != null) queryParams['budget'] = budget;

    final uri = Uri.parse('$baseUrl/packages/search')
        .replace(queryParameters: queryParams);

    try {
      final response = await _client.get(uri, headers: _headers);
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Failed to search packages: $e');
    }
  }

  // Booking API calls
  Future<Map<String, dynamic>> getUserBookings(String userId) async {
    try {
      final response = await _client.get(
        Uri.parse('$baseUrl/bookings/user/$userId'),
        headers: _headers,
      );
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Failed to get user bookings: $e');
    }
  }

  Future<Map<String, dynamic>> cancelBooking(String bookingId) async {
    try {
      final response = await _client.delete(
        Uri.parse('$baseUrl/bookings/$bookingId'),
        headers: _headers,
      );
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Failed to cancel booking: $e');
    }
  }

  // Authentication API calls
  Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    final body = {
      'email': email,
      'password': password,
    };

    try {
      final response = await _client.post(
        Uri.parse('$baseUrl/auth/login'),
        headers: _headers,
        body: json.encode(body),
      );
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Failed to login: $e');
    }
  }

  Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String password,
  }) async {
    final body = {
      'name': name,
      'email': email,
      'password': password,
    };

    try {
      final response = await _client.post(
        Uri.parse('$baseUrl/auth/register'),
        headers: _headers,
        body: json.encode(body),
      );
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Failed to register: $e');
    }
  }

  // Helper method to handle API responses
  Map<String, dynamic> _handleResponse(http.Response response) {
    final data = json.decode(response.body) as Map<String, dynamic>;
    
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return data;
    } else {
      throw Exception(data['error'] ?? 'API request failed');
    }
  }

  void dispose() {
    _client.close();
  }
}

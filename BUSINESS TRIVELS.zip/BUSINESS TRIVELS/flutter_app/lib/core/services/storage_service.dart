import 'package:shared_preferences/shared_preferences.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'dart:convert';

class StorageService {
  static late SharedPreferences _prefs;
  static late Box _box;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    await Hive.initFlutter();
    _box = await Hive.openBox('business_travels');
  }

  // SharedPreferences methods
  static Future<bool> setBool(String key, bool value) async {
    return await _prefs.setBool(key, value);
  }

  static bool getBool(String key, {bool defaultValue = false}) {
    return _prefs.getBool(key) ?? defaultValue;
  }

  static Future<bool> setString(String key, String value) async {
    return await _prefs.setString(key, value);
  }

  static String getString(String key, {String defaultValue = ''}) {
    return _prefs.getString(key) ?? defaultValue;
  }

  static Future<bool> setInt(String key, int value) async {
    return await _prefs.setInt(key, value);
  }

  static int getInt(String key, {int defaultValue = 0}) {
    return _prefs.getInt(key) ?? defaultValue;
  }

  static Future<bool> setDouble(String key, double value) async {
    return await _prefs.setDouble(key, value);
  }

  static double getDouble(String key, {double defaultValue = 0.0}) {
    return _prefs.getDouble(key) ?? defaultValue;
  }

  static Future<bool> setStringList(String key, List<String> value) async {
    return await _prefs.setStringList(key, value);
  }

  static List<String> getStringList(String key, {List<String>? defaultValue}) {
    return _prefs.getStringList(key) ?? defaultValue ?? [];
  }

  static Future<bool> remove(String key) async {
    return await _prefs.remove(key);
  }

  static Future<bool> clear() async {
    return await _prefs.clear();
  }

  // Hive methods for complex objects
  static Future<void> putObject(String key, Map<String, dynamic> value) async {
    await _box.put(key, json.encode(value));
  }

  static Map<String, dynamic>? getObject(String key) {
    final value = _box.get(key);
    if (value != null) {
      return json.decode(value) as Map<String, dynamic>;
    }
    return null;
  }

  static Future<void> putList(String key, List<Map<String, dynamic>> value) async {
    final encodedList = value.map((item) => json.encode(item)).toList();
    await _box.put(key, encodedList);
  }

  static List<Map<String, dynamic>> getList(String key) {
    final value = _box.get(key);
    if (value != null && value is List) {
      return value
          .map((item) => json.decode(item) as Map<String, dynamic>)
          .toList();
    }
    return [];
  }

  static Future<void> deleteObject(String key) async {
    await _box.delete(key);
  }

  static Future<void> clearBox() async {
    await _box.clear();
  }

  // User preferences
  static Future<void> saveUserPreferences(Map<String, dynamic> preferences) async {
    await putObject('user_preferences', preferences);
  }

  static Map<String, dynamic>? getUserPreferences() {
    return getObject('user_preferences');
  }

  // Search history
  static Future<void> saveSearchHistory(List<Map<String, dynamic>> history) async {
    await putList('search_history', history);
  }

  static List<Map<String, dynamic>> getSearchHistory() {
    return getList('search_history');
  }

  // Recent bookings cache
  static Future<void> saveRecentBookings(List<Map<String, dynamic>> bookings) async {
    await putList('recent_bookings', bookings);
  }

  static List<Map<String, dynamic>> getRecentBookings() {
    return getList('recent_bookings');
  }
}

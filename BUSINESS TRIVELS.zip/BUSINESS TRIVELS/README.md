# Business Travels - Travel Agency Web Application

A modern, comprehensive travel booking platform that allows users to search and book flights, hotels, and vacation packages with ease.

## 🌟 Features

### Core Functionality
- **Flight Booking**: Search and compare flights with filtering options
- **Hotel Reservations**: Browse hotels by location, price, and amenities
- **Package Deals**: Curated vacation bundles with combined bookings
- **User Authentication**: Sign-up/login with email and social media integration
- **Payment Processing**: Secure payments with multiple payment options
- **Booking Management**: View, modify, and cancel bookings

### User Experience
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile
- **Modern UI**: Clean, intuitive interface with dark/light mode support
- **Real-time Search**: Fast search results with loading states
- **Interactive Elements**: Smooth animations and transitions
- **Notification System**: Toast notifications for user feedback

### Additional Features
- **Travel Management**: Itinerary planner with booking details
- **Customer Support**: 24/7 chat support and FAQ section
- **Rewards Program**: Earn points for bookings (coming soon)
- **Multi-language Support**: International accessibility (coming soon)

## 🚀 Getting Started

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn package manager

### Installation

1. **Clone or download the project**
   ```bash
   cd "c:/Users/miras/OneDrive/Desktop/BUSINESS TRIVELS"
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   - Copy `.env` file and update with your API keys
   - Configure database connection (MongoDB recommended)
   - Set up payment gateway credentials (Stripe)
   - Configure email service for notifications

4. **Build CSS (if needed)**
   ```bash
   npm run build:css
   ```

5. **Start the development server**
   ```bash
   npm run dev
   ```

6. **Access the application**
   - Open your browser and navigate to `http://localhost:3000`

## 📁 Project Structure

```
BUSINESS TRIVELS/
├── public/                 # Static files
│   ├── css/               # Compiled CSS
│   ├── js/                # Client-side JavaScript
│   └── index.html         # Main HTML file
├── routes/                # API routes
│   ├── auth.js           # Authentication endpoints
│   ├── flights.js        # Flight search and booking
│   ├── hotels.js         # Hotel search and booking
│   ├── packages.js       # Package deals
│   ├── bookings.js       # Booking management
│   └── payments.js       # Payment processing
├── src/                  # Source files
│   └── input.css         # Tailwind CSS input
├── .env                  # Environment variables
├── package.json          # Dependencies and scripts
├── server.js            # Express server
├── tailwind.config.js   # Tailwind configuration
└── README.md            # This file
```

## 🛠️ API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `POST /api/auth/social` - Social media authentication
- `GET /api/auth/profile` - Get user profile
- `PUT /api/auth/profile` - Update user profile

### Flights
- `GET /api/flights/search` - Search flights
- `GET /api/flights/:id` - Get flight details
- `POST /api/flights/book` - Book a flight

### Hotels
- `GET /api/hotels/search` - Search hotels
- `GET /api/hotels/:id` - Get hotel details
- `POST /api/hotels/book` - Book a hotel

### Packages
- `GET /api/packages/search` - Search packages
- `GET /api/packages/:id` - Get package details
- `POST /api/packages/book` - Book a package

### Bookings
- `GET /api/bookings` - Get user bookings
- `GET /api/bookings/:id` - Get specific booking
- `POST /api/bookings` - Create new booking
- `PUT /api/bookings/:id/cancel` - Cancel booking

### Payments
- `POST /api/payments/process` - Process payment
- `GET /api/payments/methods` - Get payment methods
- `POST /api/payments/methods` - Add payment method
- `GET /api/payments/transactions` - Get transaction history

## 🎨 Customization

### Styling
- The application uses Tailwind CSS for styling
- Custom styles are defined in `src/input.css`
- Color scheme can be modified in `tailwind.config.js`

### Branding
- Update the app name in `public/index.html`
- Modify colors in the Tailwind configuration
- Replace placeholder images with your own assets

## 🔧 Configuration

### Environment Variables
```env
PORT=3000
MONGODB_URI=your-mongodb-connection-string
JWT_SECRET=your-jwt-secret
STRIPE_SECRET_KEY=your-stripe-secret-key
EMAIL_HOST=your-email-host
EMAIL_USER=your-email-username
EMAIL_PASS=your-email-password
```

### External APIs
The application is designed to integrate with:
- **Amadeus API** for flight data
- **Booking.com API** for hotel data
- **Stripe** for payment processing
- **Google/Facebook** for social authentication

## 📱 Mobile Responsiveness

The application is fully responsive and optimized for:
- Desktop (1024px+)
- Tablet (768px - 1023px)
- Mobile (320px - 767px)

## 🔒 Security Features

- JWT-based authentication
- Password hashing with bcrypt
- CORS protection
- Input validation and sanitization
- Secure payment processing
- Environment variable protection

## 🚀 Deployment

### Production Build
```bash
npm run build
npm start
```

### Deployment Platforms
The application can be deployed on:
- Heroku
- Vercel
- Netlify
- AWS
- DigitalOcean

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📞 Support

For support and questions:
- Email: support@businesstravels.com
- Documentation: [Link to docs]
- Issues: [GitHub Issues]

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- Tailwind CSS for the styling framework
- Font Awesome for icons
- Express.js for the backend framework
- All the amazing open-source libraries used in this project

---

**Business Travels** - Your Gateway to the World 🌍✈️

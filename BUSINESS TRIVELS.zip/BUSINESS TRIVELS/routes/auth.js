const express = require('express');
const router = express.Router();

// Mock user data for demonstration
const mockUsers = [
    {
        id: 'user001',
        email: 'demo@businesstravels.com',
        password: 'hashedpassword123', // In real app, this would be properly hashed
        firstName: 'John',
        lastName: 'Doe',
        phone: '+1-555-0123',
        preferences: {
            currency: 'USD',
            language: 'en',
            notifications: true
        }
    }
];

// POST /api/auth/register - Register new user
router.post('/register', async (req, res) => {
    try {
        const { email, password, firstName, lastName, phone } = req.body;

        if (!email || !password || !firstName || !lastName) {
            return res.status(400).json({
                error: 'Missing required fields'
            });
        }

        // Check if user already exists
        const existingUser = mockUsers.find(user => user.email === email);
        if (existingUser) {
            return res.status(409).json({
                error: 'User already exists with this email'
            });
        }

        // Simulate user creation
        await new Promise(resolve => setTimeout(resolve, 1000));

        const newUser = {
            id: 'user' + Date.now(),
            email,
            firstName,
            lastName,
            phone,
            preferences: {
                currency: 'USD',
                language: 'en',
                notifications: true
            },
            createdAt: new Date().toISOString()
        };

        mockUsers.push({ ...newUser, password: 'hashedpassword' });

        // Generate mock JWT token
        const token = generateMockToken(newUser.id);

        res.status(201).json({
            success: true,
            data: {
                user: newUser,
                token
            },
            message: 'Account created successfully!'
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            error: 'Registration failed. Please try again.'
        });
    }
});

// POST /api/auth/login - Login user
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                error: 'Email and password are required'
            });
        }

        // Simulate login delay
        await new Promise(resolve => setTimeout(resolve, 800));

        // Find user (in real app, compare hashed passwords)
        const user = mockUsers.find(u => u.email === email);
        if (!user) {
            return res.status(401).json({
                error: 'Invalid email or password'
            });
        }

        const token = generateMockToken(user.id);
        const { password: _, ...userWithoutPassword } = user;

        res.json({
            success: true,
            data: {
                user: userWithoutPassword,
                token
            },
            message: 'Login successful!'
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            error: 'Login failed. Please try again.'
        });
    }
});

// POST /api/auth/social - Social media authentication
router.post('/social', async (req, res) => {
    try {
        const { provider, token, userData } = req.body;

        if (!provider || !token || !userData) {
            return res.status(400).json({
                error: 'Missing social authentication data'
            });
        }

        // Simulate social auth verification
        await new Promise(resolve => setTimeout(resolve, 1200));

        // Check if user exists or create new one
        let user = mockUsers.find(u => u.email === userData.email);
        
        if (!user) {
            user = {
                id: 'user' + Date.now(),
                email: userData.email,
                firstName: userData.firstName || userData.name?.split(' ')[0] || '',
                lastName: userData.lastName || userData.name?.split(' ')[1] || '',
                socialProvider: provider,
                preferences: {
                    currency: 'USD',
                    language: 'en',
                    notifications: true
                },
                createdAt: new Date().toISOString()
            };
            mockUsers.push(user);
        }

        const authToken = generateMockToken(user.id);

        res.json({
            success: true,
            data: {
                user,
                token: authToken
            },
            message: `${provider} authentication successful!`
        });

    } catch (error) {
        console.error('Social auth error:', error);
        res.status(500).json({
            error: 'Social authentication failed. Please try again.'
        });
    }
});

// GET /api/auth/profile - Get user profile
router.get('/profile', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        // In real app, verify JWT token
        const userId = extractUserIdFromToken(token);
        const user = mockUsers.find(u => u.id === userId);

        if (!user) {
            return res.status(404).json({
                error: 'User not found'
            });
        }

        const { password: _, ...userProfile } = user;

        res.json({
            success: true,
            data: userProfile
        });

    } catch (error) {
        console.error('Profile fetch error:', error);
        res.status(500).json({
            error: 'Failed to fetch profile'
        });
    }
});

// PUT /api/auth/profile - Update user profile
router.put('/profile', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        const updates = req.body;

        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        const userId = extractUserIdFromToken(token);
        const userIndex = mockUsers.findIndex(u => u.id === userId);

        if (userIndex === -1) {
            return res.status(404).json({
                error: 'User not found'
            });
        }

        // Update user data
        mockUsers[userIndex] = { ...mockUsers[userIndex], ...updates };
        const { password: _, ...updatedUser } = mockUsers[userIndex];

        res.json({
            success: true,
            data: updatedUser,
            message: 'Profile updated successfully!'
        });

    } catch (error) {
        console.error('Profile update error:', error);
        res.status(500).json({
            error: 'Failed to update profile'
        });
    }
});

// POST /api/auth/logout - Logout user
router.post('/logout', async (req, res) => {
    try {
        // In real app, invalidate token
        res.json({
            success: true,
            message: 'Logged out successfully!'
        });
    } catch (error) {
        console.error('Logout error:', error);
        res.status(500).json({
            error: 'Logout failed'
        });
    }
});

function generateMockToken(userId) {
    // In real app, use proper JWT library
    return `mock_token_${userId}_${Date.now()}`;
}

function extractUserIdFromToken(token) {
    // In real app, verify and decode JWT
    const parts = token.split('_');
    return parts.length >= 3 ? parts[2] : null;
}

module.exports = router;

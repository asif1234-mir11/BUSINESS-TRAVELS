const express = require('express');
const router = express.Router();

// Mock bookings data
const mockBookings = [];

// GET /api/bookings - Get user bookings
router.get('/', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        const userId = extractUserIdFromToken(token);
        const userBookings = mockBookings.filter(booking => booking.userId === userId);

        res.json({
            success: true,
            data: {
                bookings: userBookings,
                totalBookings: userBookings.length
            }
        });

    } catch (error) {
        console.error('Get bookings error:', error);
        res.status(500).json({
            error: 'Failed to fetch bookings'
        });
    }
});

// GET /api/bookings/:id - Get specific booking
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        const userId = extractUserIdFromToken(token);
        const booking = mockBookings.find(b => b.id === id && b.userId === userId);

        if (!booking) {
            return res.status(404).json({
                error: 'Booking not found'
            });
        }

        res.json({
            success: true,
            data: booking
        });

    } catch (error) {
        console.error('Get booking error:', error);
        res.status(500).json({
            error: 'Failed to fetch booking'
        });
    }
});

// POST /api/bookings - Create new booking
router.post('/', async (req, res) => {
    try {
        const { type, itemId, details, paymentInfo } = req.body;
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        if (!type || !itemId || !details || !paymentInfo) {
            return res.status(400).json({
                error: 'Missing required booking information'
            });
        }

        const userId = extractUserIdFromToken(token);
        
        // Simulate booking process
        await new Promise(resolve => setTimeout(resolve, 2000));

        const booking = {
            id: 'BK' + Date.now(),
            userId,
            type, // 'flight', 'hotel', 'package'
            itemId,
            details,
            paymentInfo: {
                amount: paymentInfo.amount,
                currency: paymentInfo.currency,
                method: paymentInfo.method
            },
            status: 'confirmed',
            confirmationCode: generateConfirmationCode(),
            bookingDate: new Date().toISOString(),
            createdAt: new Date().toISOString()
        };

        mockBookings.push(booking);

        res.status(201).json({
            success: true,
            data: booking,
            message: 'Booking created successfully!'
        });

    } catch (error) {
        console.error('Create booking error:', error);
        res.status(500).json({
            error: 'Booking failed. Please try again.'
        });
    }
});

// PUT /api/bookings/:id/cancel - Cancel booking
router.put('/:id/cancel', async (req, res) => {
    try {
        const { id } = req.params;
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        const userId = extractUserIdFromToken(token);
        const bookingIndex = mockBookings.findIndex(b => b.id === id && b.userId === userId);

        if (bookingIndex === -1) {
            return res.status(404).json({
                error: 'Booking not found'
            });
        }

        // Check if booking can be cancelled
        const booking = mockBookings[bookingIndex];
        if (booking.status === 'cancelled') {
            return res.status(400).json({
                error: 'Booking is already cancelled'
            });
        }

        // Update booking status
        mockBookings[bookingIndex].status = 'cancelled';
        mockBookings[bookingIndex].cancelledAt = new Date().toISOString();

        res.json({
            success: true,
            data: mockBookings[bookingIndex],
            message: 'Booking cancelled successfully!'
        });

    } catch (error) {
        console.error('Cancel booking error:', error);
        res.status(500).json({
            error: 'Failed to cancel booking'
        });
    }
});

// GET /api/bookings/stats - Get booking statistics
router.get('/user/stats', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        const userId = extractUserIdFromToken(token);
        const userBookings = mockBookings.filter(booking => booking.userId === userId);

        const stats = {
            totalBookings: userBookings.length,
            confirmedBookings: userBookings.filter(b => b.status === 'confirmed').length,
            cancelledBookings: userBookings.filter(b => b.status === 'cancelled').length,
            totalSpent: userBookings.reduce((sum, b) => sum + (b.paymentInfo?.amount || 0), 0),
            bookingsByType: {
                flights: userBookings.filter(b => b.type === 'flight').length,
                hotels: userBookings.filter(b => b.type === 'hotel').length,
                packages: userBookings.filter(b => b.type === 'package').length
            }
        };

        res.json({
            success: true,
            data: stats
        });

    } catch (error) {
        console.error('Get booking stats error:', error);
        res.status(500).json({
            error: 'Failed to fetch booking statistics'
        });
    }
});

function extractUserIdFromToken(token) {
    const parts = token.split('_');
    return parts.length >= 3 ? parts[2] : null;
}

function generateConfirmationCode() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

module.exports = router;

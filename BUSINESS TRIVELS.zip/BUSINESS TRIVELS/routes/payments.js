const express = require('express');
const router = express.Router();

// Mock payment methods and transactions
const mockPaymentMethods = [];
const mockTransactions = [];

// POST /api/payments/process - Process payment
router.post('/process', async (req, res) => {
    try {
        const { amount, currency, paymentMethod, bookingDetails } = req.body;
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        if (!amount || !currency || !paymentMethod || !bookingDetails) {
            return res.status(400).json({
                error: 'Missing required payment information'
            });
        }

        const userId = extractUserIdFromToken(token);

        // Simulate payment processing delay
        await new Promise(resolve => setTimeout(resolve, 3000));

        // Simulate payment success (90% success rate)
        const isSuccess = Math.random() > 0.1;

        if (!isSuccess) {
            return res.status(402).json({
                error: 'Payment failed. Please check your payment details and try again.'
            });
        }

        const transaction = {
            id: 'TXN' + Date.now(),
            userId,
            amount,
            currency,
            paymentMethod,
            bookingDetails,
            status: 'completed',
            transactionDate: new Date().toISOString(),
            confirmationNumber: generateConfirmationNumber()
        };

        mockTransactions.push(transaction);

        res.json({
            success: true,
            data: transaction,
            message: 'Payment processed successfully!'
        });

    } catch (error) {
        console.error('Payment processing error:', error);
        res.status(500).json({
            error: 'Payment processing failed. Please try again.'
        });
    }
});

// GET /api/payments/methods - Get user payment methods
router.get('/methods', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        const userId = extractUserIdFromToken(token);
        const userPaymentMethods = mockPaymentMethods.filter(method => method.userId === userId);

        res.json({
            success: true,
            data: {
                paymentMethods: userPaymentMethods,
                supportedMethods: [
                    { type: 'credit_card', name: 'Credit Card', icon: 'fas fa-credit-card' },
                    { type: 'debit_card', name: 'Debit Card', icon: 'fas fa-credit-card' },
                    { type: 'paypal', name: 'PayPal', icon: 'fab fa-paypal' },
                    { type: 'apple_pay', name: 'Apple Pay', icon: 'fab fa-apple-pay' },
                    { type: 'google_pay', name: 'Google Pay', icon: 'fab fa-google-pay' }
                ]
            }
        });

    } catch (error) {
        console.error('Get payment methods error:', error);
        res.status(500).json({
            error: 'Failed to fetch payment methods'
        });
    }
});

// POST /api/payments/methods - Add payment method
router.post('/methods', async (req, res) => {
    try {
        const { type, details } = req.body;
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        if (!type || !details) {
            return res.status(400).json({
                error: 'Payment method type and details are required'
            });
        }

        const userId = extractUserIdFromToken(token);

        const paymentMethod = {
            id: 'PM' + Date.now(),
            userId,
            type,
            details: {
                ...details,
                // Mask sensitive information
                cardNumber: details.cardNumber ? '**** **** **** ' + details.cardNumber.slice(-4) : undefined
            },
            isDefault: mockPaymentMethods.filter(m => m.userId === userId).length === 0,
            createdAt: new Date().toISOString()
        };

        mockPaymentMethods.push(paymentMethod);

        res.status(201).json({
            success: true,
            data: paymentMethod,
            message: 'Payment method added successfully!'
        });

    } catch (error) {
        console.error('Add payment method error:', error);
        res.status(500).json({
            error: 'Failed to add payment method'
        });
    }
});

// DELETE /api/payments/methods/:id - Remove payment method
router.delete('/methods/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        const userId = extractUserIdFromToken(token);
        const methodIndex = mockPaymentMethods.findIndex(m => m.id === id && m.userId === userId);

        if (methodIndex === -1) {
            return res.status(404).json({
                error: 'Payment method not found'
            });
        }

        mockPaymentMethods.splice(methodIndex, 1);

        res.json({
            success: true,
            message: 'Payment method removed successfully!'
        });

    } catch (error) {
        console.error('Remove payment method error:', error);
        res.status(500).json({
            error: 'Failed to remove payment method'
        });
    }
});

// GET /api/payments/transactions - Get transaction history
router.get('/transactions', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        const { page = 1, limit = 10 } = req.query;
        
        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        const userId = extractUserIdFromToken(token);
        const userTransactions = mockTransactions.filter(txn => txn.userId === userId);
        
        // Pagination
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + parseInt(limit);
        const paginatedTransactions = userTransactions.slice(startIndex, endIndex);

        res.json({
            success: true,
            data: {
                transactions: paginatedTransactions,
                pagination: {
                    currentPage: parseInt(page),
                    totalPages: Math.ceil(userTransactions.length / limit),
                    totalTransactions: userTransactions.length,
                    hasNext: endIndex < userTransactions.length,
                    hasPrev: startIndex > 0
                }
            }
        });

    } catch (error) {
        console.error('Get transactions error:', error);
        res.status(500).json({
            error: 'Failed to fetch transaction history'
        });
    }
});

// POST /api/payments/refund - Request refund
router.post('/refund', async (req, res) => {
    try {
        const { transactionId, reason } = req.body;
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                error: 'Authentication token required'
            });
        }

        if (!transactionId || !reason) {
            return res.status(400).json({
                error: 'Transaction ID and reason are required'
            });
        }

        const userId = extractUserIdFromToken(token);
        const transaction = mockTransactions.find(txn => txn.id === transactionId && txn.userId === userId);

        if (!transaction) {
            return res.status(404).json({
                error: 'Transaction not found'
            });
        }

        // Simulate refund processing
        await new Promise(resolve => setTimeout(resolve, 2000));

        const refund = {
            id: 'REF' + Date.now(),
            transactionId,
            userId,
            amount: transaction.amount,
            currency: transaction.currency,
            reason,
            status: 'pending',
            requestDate: new Date().toISOString()
        };

        res.json({
            success: true,
            data: refund,
            message: 'Refund request submitted successfully! We will process it within 3-5 business days.'
        });

    } catch (error) {
        console.error('Refund request error:', error);
        res.status(500).json({
            error: 'Failed to process refund request'
        });
    }
});

function extractUserIdFromToken(token) {
    const parts = token.split('_');
    return parts.length >= 3 ? parts[2] : null;
}

function generateConfirmationNumber() {
    return 'CNF' + Math.random().toString(36).substring(2, 10).toUpperCase();
}

module.exports = router;

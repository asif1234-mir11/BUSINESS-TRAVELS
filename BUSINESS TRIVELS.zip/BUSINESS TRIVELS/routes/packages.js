const express = require('express');
const router = express.Router();

// Mock package data
const mockPackages = [
    {
        id: 'PK001',
        name: 'European Adventure',
        destination: 'Paris, Rome, Barcelona',
        duration: '10 days',
        price: 2499,
        includes: ['Round-trip flights', 'Hotel accommodation', 'Daily breakfast', 'Airport transfers', 'City tours'],
        rating: 4.8,
        images: ['https://via.placeholder.com/500x350?text=European+Adventure'],
        description: 'Explore the best of Europe with this comprehensive package.',
        highlights: ['Eiffel Tower visit', 'Colosseum tour', 'Sagrada Familia']
    }
];

// GET /api/packages/search - Search for packages
router.get('/search', async (req, res) => {
    try {
        const { destination, duration, budget, travelers } = req.query;

        if (!destination) {
            return res.status(400).json({
                error: 'Destination is required'
            });
        }

        await new Promise(resolve => setTimeout(resolve, 1500));

        const results = generatePackageResults(destination, duration, budget, travelers);

        res.json({
            success: true,
            data: {
                packages: results,
                searchParams: { destination, duration, budget, travelers },
                totalResults: results.length
            }
        });

    } catch (error) {
        console.error('Package search error:', error);
        res.status(500).json({
            error: 'Internal server error during package search'
        });
    }
});

// GET /api/packages/:id - Get package details
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pkg = mockPackages.find(p => p.id === id);

        if (!pkg) {
            return res.status(404).json({
                error: 'Package not found'
            });
        }

        res.json({
            success: true,
            data: pkg
        });

    } catch (error) {
        console.error('Get package error:', error);
        res.status(500).json({
            error: 'Internal server error'
        });
    }
});

// POST /api/packages/book - Book a package
router.post('/book', async (req, res) => {
    try {
        const { packageId, travelerInfo, paymentInfo, preferences } = req.body;

        if (!packageId || !travelerInfo || !paymentInfo) {
            return res.status(400).json({
                error: 'Missing required booking information'
            });
        }

        await new Promise(resolve => setTimeout(resolve, 3000));

        const bookingId = 'PB' + Date.now();
        const booking = {
            bookingId,
            packageId,
            travelerInfo,
            preferences,
            status: 'confirmed',
            bookingDate: new Date().toISOString(),
            confirmationCode: generateConfirmationCode()
        };

        res.json({
            success: true,
            data: booking,
            message: 'Package booked successfully!'
        });

    } catch (error) {
        console.error('Package booking error:', error);
        res.status(500).json({
            error: 'Booking failed. Please try again.'
        });
    }
});

function generatePackageResults(destination, duration, budget, travelers) {
    const packageTypes = [
        'Adventure Package', 'Luxury Getaway', 'Cultural Experience', 
        'Beach Paradise', 'City Explorer', 'Romantic Escape',
        'Family Fun Package', 'Business Travel Package'
    ];

    const includes = [
        ['Round-trip flights', 'Hotel accommodation', 'Daily breakfast', 'Airport transfers'],
        ['Round-trip flights', '4-star hotels', 'Half-board meals', 'Guided tours', 'Travel insurance'],
        ['Flights', 'Luxury resorts', 'All meals included', 'Private transfers', 'Spa treatments'],
        ['Flights', 'Boutique hotels', 'City tours', 'Museum passes', 'Local experiences']
    ];

    const results = [];
    const budgetMultiplier = getBudgetMultiplier(budget);

    for (let i = 0; i < 8; i++) {
        const basePrice = Math.floor(Math.random() * 2000) + 500;
        const finalPrice = Math.floor(basePrice * budgetMultiplier);
        const rating = (Math.random() * 1.5 + 3.5).toFixed(1);

        results.push({
            id: `PK${String(i + 100).padStart(3, '0')}`,
            name: `${destination} ${packageTypes[Math.floor(Math.random() * packageTypes.length)]}`,
            destination,
            duration: duration || `${Math.floor(Math.random() * 10) + 3} days`,
            price: finalPrice,
            includes: includes[Math.floor(Math.random() * includes.length)],
            rating: parseFloat(rating),
            images: [`https://via.placeholder.com/500x350?text=Package+${i+1}`],
            description: `Experience the best of ${destination} with this carefully curated travel package.`,
            highlights: generateHighlights(destination),
            savings: Math.floor(Math.random() * 500) + 200
        });
    }

    return results.sort((a, b) => b.rating - a.rating);
}

function getBudgetMultiplier(budget) {
    switch(budget) {
        case 'Under $1,000': return 0.7;
        case '$1,000 - $3,000': return 1.0;
        case '$3,000 - $5,000': return 1.8;
        case '$5,000+': return 2.5;
        default: return 1.0;
    }
}

function generateHighlights(destination) {
    const highlights = {
        'Paris': ['Eiffel Tower visit', 'Louvre Museum', 'Seine River cruise'],
        'Tokyo': ['Mount Fuji tour', 'Traditional temples', 'Sushi experience'],
        'New York': ['Statue of Liberty', 'Broadway show', 'Central Park'],
        'London': ['Big Ben tour', 'British Museum', 'Thames cruise'],
        'Rome': ['Colosseum tour', 'Vatican City', 'Trevi Fountain']
    };

    return highlights[destination] || ['Local attractions', 'Cultural experiences', 'Scenic tours'];
}

function generateConfirmationCode() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

module.exports = router;

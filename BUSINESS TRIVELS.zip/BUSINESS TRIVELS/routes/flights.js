const express = require('express');
const router = express.Router();

// Mock flight data for demonstration
const mockFlights = [
    {
        id: 'FL001',
        airline: 'Delta Airlines',
        from: 'New York (JFK)',
        to: 'Los Angeles (LAX)',
        departTime: '08:30 AM',
        arriveTime: '11:45 AM',
        duration: '5h 15m',
        price: 299,
        stops: 0,
        aircraft: 'Boeing 737',
        class: 'Economy'
    },
    {
        id: 'FL002',
        airline: 'American Airlines',
        from: 'Chicago (ORD)',
        to: 'Miami (MIA)',
        departTime: '02:15 PM',
        arriveTime: '05:30 PM',
        duration: '3h 15m',
        price: 189,
        stops: 0,
        aircraft: 'Airbus A320',
        class: 'Economy'
    }
];

// GET /api/flights/search - Search for flights
router.get('/search', async (req, res) => {
    try {
        const { from, to, departDate, returnDate, passengers, class: flightClass } = req.query;

        // Validate required fields
        if (!from || !to || !departDate) {
            return res.status(400).json({
                error: 'Missing required fields: from, to, departDate'
            });
        }

        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Filter and return mock results
        const results = mockFlights.filter(flight => 
            flight.from.toLowerCase().includes(from.toLowerCase()) ||
            flight.to.toLowerCase().includes(to.toLowerCase())
        );

        // Generate additional mock results based on search
        const generatedResults = generateFlightResults(from, to, departDate, returnDate, passengers, flightClass);

        res.json({
            success: true,
            data: {
                flights: [...results, ...generatedResults],
                searchParams: { from, to, departDate, returnDate, passengers, class: flightClass },
                totalResults: results.length + generatedResults.length
            }
        });

    } catch (error) {
        console.error('Flight search error:', error);
        res.status(500).json({
            error: 'Internal server error during flight search'
        });
    }
});

// GET /api/flights/:id - Get flight details
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const flight = mockFlights.find(f => f.id === id);

        if (!flight) {
            return res.status(404).json({
                error: 'Flight not found'
            });
        }

        res.json({
            success: true,
            data: flight
        });

    } catch (error) {
        console.error('Get flight error:', error);
        res.status(500).json({
            error: 'Internal server error'
        });
    }
});

// POST /api/flights/book - Book a flight
router.post('/book', async (req, res) => {
    try {
        const { flightId, passengerInfo, paymentInfo } = req.body;

        // Validate required fields
        if (!flightId || !passengerInfo || !paymentInfo) {
            return res.status(400).json({
                error: 'Missing required booking information'
            });
        }

        // Simulate booking process
        await new Promise(resolve => setTimeout(resolve, 2000));

        const bookingId = 'BK' + Date.now();
        const booking = {
            bookingId,
            flightId,
            passengerInfo,
            status: 'confirmed',
            bookingDate: new Date().toISOString(),
            confirmationCode: generateConfirmationCode()
        };

        res.json({
            success: true,
            data: booking,
            message: 'Flight booked successfully!'
        });

    } catch (error) {
        console.error('Flight booking error:', error);
        res.status(500).json({
            error: 'Booking failed. Please try again.'
        });
    }
});

// Helper function to generate flight results
function generateFlightResults(from, to, departDate, returnDate, passengers, flightClass) {
    const airlines = ['Delta Airlines', 'American Airlines', 'United Airlines', 'Southwest Airlines', 'JetBlue Airways'];
    const results = [];

    for (let i = 0; i < 8; i++) {
        const basePrice = Math.floor(Math.random() * 600) + 150;
        const classMultiplier = flightClass === 'Business' ? 3 : flightClass === 'First Class' ? 5 : 1;
        
        results.push({
            id: `FL${String(i + 100).padStart(3, '0')}`,
            airline: airlines[Math.floor(Math.random() * airlines.length)],
            from: from,
            to: to,
            departTime: generateRandomTime(),
            arriveTime: generateRandomTime(),
            duration: generateRandomDuration(),
            price: Math.floor(basePrice * classMultiplier),
            stops: Math.floor(Math.random() * 3),
            aircraft: ['Boeing 737', 'Airbus A320', 'Boeing 777', 'Airbus A350'][Math.floor(Math.random() * 4)],
            class: flightClass || 'Economy',
            departDate: departDate,
            returnDate: returnDate
        });
    }

    return results;
}

function generateRandomTime() {
    const hours = Math.floor(Math.random() * 24);
    const minutes = Math.floor(Math.random() * 4) * 15; // 0, 15, 30, 45
    const period = hours >= 12 ? 'PM' : 'AM';
    const displayHours = hours === 0 ? 12 : hours > 12 ? hours - 12 : hours;
    return `${displayHours}:${minutes.toString().padStart(2, '0')} ${period}`;
}

function generateRandomDuration() {
    const hours = Math.floor(Math.random() * 8) + 1;
    const minutes = Math.floor(Math.random() * 4) * 15;
    return `${hours}h ${minutes}m`;
}

function generateConfirmationCode() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

module.exports = router;

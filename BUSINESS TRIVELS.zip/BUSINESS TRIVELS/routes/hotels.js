const express = require('express');
const router = express.Router();

// Mock hotel data
const mockHotels = [
    {
        id: 'HT001',
        name: 'Grand Plaza Hotel',
        location: 'New York, NY',
        rating: 4.5,
        price: 299,
        amenities: ['Free WiFi', 'Pool', 'Gym', 'Restaurant', 'Spa', 'Business Center'],
        images: ['https://via.placeholder.com/400x300?text=Grand+Plaza+1'],
        description: 'Luxury hotel in the heart of Manhattan with world-class amenities.',
        cancellationPolicy: 'Free cancellation up to 24 hours before check-in'
    },
    {
        id: 'HT002',
        name: 'Comfort Inn & Suites',
        location: 'Los Angeles, CA',
        rating: 4.2,
        price: 189,
        amenities: ['Free WiFi', 'Pool', 'Breakfast', 'Parking'],
        images: ['https://via.placeholder.com/400x300?text=Comfort+Inn+1'],
        description: 'Comfortable accommodations near LAX airport.',
        cancellationPolicy: 'Free cancellation up to 48 hours before check-in'
    }
];

// GET /api/hotels/search - Search for hotels
router.get('/search', async (req, res) => {
    try {
        const { destination, checkinDate, checkoutDate, rooms, guests } = req.query;

        if (!destination || !checkinDate || !checkoutDate) {
            return res.status(400).json({
                error: 'Missing required fields: destination, checkinDate, checkoutDate'
            });
        }

        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1200));

        // Generate mock results
        const results = generateHotelResults(destination, checkinDate, checkoutDate, rooms, guests);

        res.json({
            success: true,
            data: {
                hotels: results,
                searchParams: { destination, checkinDate, checkoutDate, rooms, guests },
                totalResults: results.length
            }
        });

    } catch (error) {
        console.error('Hotel search error:', error);
        res.status(500).json({
            error: 'Internal server error during hotel search'
        });
    }
});

// GET /api/hotels/:id - Get hotel details
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const hotel = mockHotels.find(h => h.id === id);

        if (!hotel) {
            return res.status(404).json({
                error: 'Hotel not found'
            });
        }

        res.json({
            success: true,
            data: hotel
        });

    } catch (error) {
        console.error('Get hotel error:', error);
        res.status(500).json({
            error: 'Internal server error'
        });
    }
});

// POST /api/hotels/book - Book a hotel
router.post('/book', async (req, res) => {
    try {
        const { hotelId, guestInfo, roomDetails, paymentInfo } = req.body;

        if (!hotelId || !guestInfo || !roomDetails || !paymentInfo) {
            return res.status(400).json({
                error: 'Missing required booking information'
            });
        }

        // Simulate booking process
        await new Promise(resolve => setTimeout(resolve, 2500));

        const bookingId = 'HB' + Date.now();
        const booking = {
            bookingId,
            hotelId,
            guestInfo,
            roomDetails,
            status: 'confirmed',
            bookingDate: new Date().toISOString(),
            confirmationCode: generateConfirmationCode()
        };

        res.json({
            success: true,
            data: booking,
            message: 'Hotel booked successfully!'
        });

    } catch (error) {
        console.error('Hotel booking error:', error);
        res.status(500).json({
            error: 'Booking failed. Please try again.'
        });
    }
});

function generateHotelResults(destination, checkinDate, checkoutDate, rooms, guests) {
    const hotelNames = [
        'Grand Plaza Hotel', 'Luxury Resort & Spa', 'Business Center Inn', 
        'Comfort Suites', 'Royal Palace Hotel', 'Seaside Resort', 
        'Downtown Boutique Hotel', 'Airport Express Inn'
    ];
    
    const amenitiesList = [
        ['Free WiFi', 'Pool', 'Gym', 'Restaurant'],
        ['Free WiFi', 'Spa', 'Business Center', 'Valet Parking'],
        ['Free WiFi', 'Breakfast', 'Airport Shuttle', 'Fitness Center'],
        ['Free WiFi', 'Pool', 'Restaurant', 'Room Service'],
        ['Free WiFi', 'Gym', 'Concierge', 'Laundry Service']
    ];

    const results = [];

    for (let i = 0; i < 10; i++) {
        const basePrice = Math.floor(Math.random() * 400) + 100;
        const rating = (Math.random() * 2 + 3).toFixed(1);
        
        results.push({
            id: `HT${String(i + 100).padStart(3, '0')}`,
            name: hotelNames[Math.floor(Math.random() * hotelNames.length)],
            location: destination,
            rating: parseFloat(rating),
            price: basePrice,
            amenities: amenitiesList[Math.floor(Math.random() * amenitiesList.length)],
            images: [`https://via.placeholder.com/400x300?text=Hotel+${i+1}`],
            description: `Beautiful hotel in ${destination} with excellent service and modern amenities.`,
            cancellationPolicy: 'Free cancellation up to 24 hours before check-in',
            checkinDate,
            checkoutDate,
            availableRooms: Math.floor(Math.random() * 10) + 1
        });
    }

    return results.sort((a, b) => b.rating - a.rating);
}

function generateConfirmationCode() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

module.exports = router;

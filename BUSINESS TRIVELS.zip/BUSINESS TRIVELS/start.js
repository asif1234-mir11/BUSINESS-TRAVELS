// Simple startup script for Business Travels
const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(express.static('public'));
app.use(express.json());

// Basic route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Mock API routes for testing
app.get('/api/test', (req, res) => {
    res.json({ message: 'Business Travels API is working!' });
});

app.listen(PORT, () => {
    console.log(`🚀 Business Travels running at http://localhost:${PORT}`);
});

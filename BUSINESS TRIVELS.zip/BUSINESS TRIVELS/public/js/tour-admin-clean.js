// Tour Admin Panel JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initializeAdminPanel();
    initializeCharts();
    initializeEventListeners();
});

function initializeAdminPanel() {
    showSection('dashboard');
    
    // Initialize sidebar navigation
    const navItems = document.querySelectorAll('nav a[href^="#"]');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const href = this.getAttribute('href');
            const target = href.substring(1); // Remove the # symbol
            showSection(target);
            
            // Update active nav item
            navItems.forEach(nav => nav.classList.remove('bg-blue-700', 'text-white'));
            navItems.forEach(nav => nav.classList.add('text-gray-300', 'hover:bg-blue-700', 'hover:text-white'));
            
            this.classList.remove('text-gray-300', 'hover:bg-blue-700', 'hover:text-white');
            this.classList.add('bg-blue-700', 'text-white');
        });
    });
    
    // Initialize sidebar toggle
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('-translate-x-full');
            if (overlay) {
                overlay.classList.toggle('hidden');
            }
        });
    }
    
    if (overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.add('-translate-x-full');
            overlay.classList.add('hidden');
        });
    }
}

function showSection(sectionId) {
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => section.classList.add('hidden'));
    const targetSection = document.getElementById(sectionId);
    if (targetSection) targetSection.classList.remove('hidden');
    loadSectionData(sectionId);
}

function loadSectionData(sectionId) {
    switch(sectionId) {
        case 'dashboard':
            loadDashboardData();
            break;
        case 'bookings':
            loadBookingsData();
            break;
        case 'packages':
            loadPackagesData();
            break;
        case 'customers':
            loadCustomersData();
            break;
        case 'payments':
            loadPaymentsData();
            break;
    }
}

function initializeCharts() {
    // Enhanced Bookings Trend Chart
    const bookingsCtx = document.getElementById('bookingsChart');
    if (bookingsCtx) {
        new Chart(bookingsCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'],
                datasets: [{
                    label: 'Bookings',
                    data: [120, 190, 300, 500, 420, 650, 780, 920],
                    borderColor: 'rgb(59, 130, 246)',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: 'rgb(59, 130, 246)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6,
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: 'rgb(59, 130, 246)',
                        borderWidth: 1
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    }
                }
            }
        });
    }

    // Enhanced Revenue Growth Chart
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx) {
        new Chart(revenueCtx, {
            type: 'bar',
            data: {
                labels: ['Q1', 'Q2', 'Q3', 'Q4'],
                datasets: [{
                    label: 'Revenue ($)',
                    data: [85000, 120000, 95000, 140000],
                    backgroundColor: [
                        'rgba(34, 197, 94, 0.8)',
                        'rgba(34, 197, 94, 0.9)',
                        'rgba(34, 197, 94, 0.7)',
                        'rgba(34, 197, 94, 1)'
                    ],
                    borderColor: 'rgb(34, 197, 94)',
                    borderWidth: 2,
                    borderRadius: 8,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: 'rgb(34, 197, 94)',
                        borderWidth: 1,
                        callbacks: {
                            label: function(context) {
                                return '$' + context.parsed.y.toLocaleString();
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            color: '#6b7280',
                            callback: function(value) {
                                return '$' + (value / 1000) + 'K';
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    }
                }
            }
        });
    }

    // Add a third chart for payment analytics if canvas exists
    const paymentCtx = document.getElementById('paymentChart');
    if (paymentCtx) {
        new Chart(paymentCtx, {
            type: 'doughnut',
            data: {
                labels: ['Stripe', 'PayPal', 'Razorpay', 'Bank Transfer'],
                datasets: [{
                    data: [45, 25, 20, 10],
                    backgroundColor: [
                        'rgba(99, 102, 241, 0.8)',
                        'rgba(34, 197, 94, 0.8)',
                        'rgba(168, 85, 247, 0.8)',
                        'rgba(249, 115, 22, 0.8)'
                    ],
                    borderColor: [
                        'rgb(99, 102, 241)',
                        'rgb(34, 197, 94)',
                        'rgb(168, 85, 247)',
                        'rgb(249, 115, 22)'
                    ],
                    borderWidth: 2,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            color: '#6b7280'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.parsed + '%';
                            }
                        }
                    }
                }
            }
        });
    }
}

function initializeEventListeners() {
    const quickActions = document.querySelectorAll('.quick-action');
    quickActions.forEach(action => {
        action.addEventListener('click', function() {
            const actionType = this.getAttribute('data-action');
            handleQuickAction(actionType);
        });
    });

    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal-close') || e.target.closest('.modal-close')) {
            closeModal(e.target);
        }
    });

    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            handleFormSubmission(this);
        });
    });
}

function handleQuickAction(actionType) {
    switch(actionType) {
        case 'new-booking':
            showModal('newBookingModal');
            break;
        case 'new-package':
            createPackage();
            break;
        case 'new-customer':
            showModal('newCustomerModal');
            break;
        case 'export-data':
            exportData();
            break;
        default:
            console.log('Unknown action:', actionType);
    }
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(element) {
    const modal = element.closest('.modal') || element.closest('[id$="Modal"]');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        document.body.style.overflow = 'auto';
    }
}

function handleFormSubmission(form) {
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Processing...';
    submitBtn.disabled = true;

    setTimeout(() => {
        console.log('Form submitted:', data);
        showNotification('Data saved successfully!', 'success');
        form.reset();
        closeModal(form);
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }, 1000);
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg transform transition-all duration-300 translate-x-full ${getNotificationClasses(type)}`;
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas ${getNotificationIcon(type)} mr-3"></i>
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white hover:text-gray-200">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 300);
    }, 5000);
}

function getNotificationClasses(type) {
    switch(type) {
        case 'success':
            return 'bg-green-500 text-white';
        case 'error':
            return 'bg-red-500 text-white';
        case 'warning':
            return 'bg-yellow-500 text-white';
        default:
            return 'bg-blue-500 text-white';
    }
}

function getNotificationIcon(type) {
    switch(type) {
        case 'success':
            return 'fa-check-circle';
        case 'error':
            return 'fa-exclamation-circle';
        case 'warning':
            return 'fa-exclamation-triangle';
        default:
            return 'fa-info-circle';
    }
}

// Data loading functions
function loadDashboardData() {
    console.log('Loading dashboard data...');
}

function loadBookingsData() {
    console.log('Loading bookings data...');
}

function loadPackagesData() {
    console.log('Loading packages data...');
}

function loadCustomersData() {
    console.log('Loading customers data...');
}

function loadPaymentsData() {
    console.log('Loading payments data...');
}

function exportData() {
    console.log('Exporting data...');
    showNotification('Export started - you will receive an email when ready', 'info');
}

// Package Management Functions
window.createPackage = function() {
    showModal('packageModal');
    const form = document.getElementById('packageForm');
    if (form) form.reset();
    const title = document.getElementById('packageModalTitle');
    if (title) title.textContent = 'Create New Package';
    const container = document.getElementById('itineraryContainer');
    if (container) {
        container.innerHTML = '';
        addItineraryDay();
    }
};

window.editPackage = function(id) {
    showModal('packageModal');
    const title = document.getElementById('packageModalTitle');
    if (title) title.textContent = 'Edit Package';
    console.log('Editing package:', id);
};

window.deletePackage = function(id) {
    if (confirm('Are you sure you want to delete this package?')) {
        console.log('Deleting package:', id);
        showNotification('Package deleted successfully', 'success');
    }
};

window.duplicatePackage = function(id) {
    console.log('Duplicating package:', id);
    showNotification('Package duplicated successfully', 'success');
};

window.addItineraryDay = function() {
    const container = document.getElementById('itineraryContainer');
    if (!container) return;
    
    const dayCount = container.children.length + 1;
    const dayDiv = document.createElement('div');
    dayDiv.className = 'itinerary-day border border-gray-200 rounded-lg p-4 mb-4';
    dayDiv.innerHTML = `
        <div class="flex justify-between items-center mb-3">
            <h4 class="font-medium text-gray-900">Day ${dayCount}</h4>
            <button type="button" onclick="removeItineraryDay(this)" class="text-red-600 hover:text-red-800">
                <i class="fas fa-trash"></i>
            </button>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input type="text" placeholder="Day title" class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
            <input type="text" placeholder="Location" class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
        </div>
        <textarea placeholder="Activities and description" rows="3" class="w-full mt-3 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"></textarea>
    `;
    container.appendChild(dayDiv);
};

window.removeItineraryDay = function(button) {
    const dayDiv = button.closest('.itinerary-day');
    if (dayDiv) dayDiv.remove();
    
    const days = document.querySelectorAll('.itinerary-day h4');
    days.forEach((day, index) => {
        day.textContent = `Day ${index + 1}`;
    });
};

// Package filtering with debounce
let packageFilterTimeout;
window.filterPackages = function() {
    clearTimeout(packageFilterTimeout);
    packageFilterTimeout = setTimeout(() => {
        const searchInput = document.querySelector('#packages input[placeholder="Search packages..."]');
        const searchTerm = searchInput ? searchInput.value : '';
        console.log('Filtering packages:', searchTerm);
    }, 300);
};

// Payment Management Functions
window.viewPaymentDetails = function(transactionId) {
    console.log('Viewing payment details for:', transactionId);
    showNotification('Payment details loaded', 'info');
};

window.downloadInvoice = function(transactionId) {
    console.log('Downloading invoice for:', transactionId);
    showNotification('Invoice download started', 'success');
};

window.sendReceipt = function(transactionId) {
    console.log('Sending receipt for:', transactionId);
    showNotification('Receipt sent successfully', 'success');
};

window.processRefund = function(transactionId) {
    if (confirm('Are you sure you want to process a refund for this transaction?')) {
        console.log('Processing refund for:', transactionId);
        showNotification('Refund processed successfully', 'success');
    }
};

window.cancelPayment = function(transactionId) {
    if (confirm('Are you sure you want to cancel this payment?')) {
        console.log('Cancelling payment for:', transactionId);
        showNotification('Payment cancelled', 'warning');
    }
};

window.addManualPayment = function() {
    showModal('manualPaymentModal');
};

window.generateInvoice = function() {
    showModal('invoiceModal');
};

window.exportPayments = function() {
    console.log('Exporting payments data');
    showNotification('Export started - you will receive an email when ready', 'info');
};

// Payment filtering
let paymentFilterTimeout;
window.filterPayments = function() {
    clearTimeout(paymentFilterTimeout);
    paymentFilterTimeout = setTimeout(() => {
        const searchInput = document.querySelector('#payments input[placeholder="Search transactions..."]');
        const statusSelect = document.querySelector('#payments select');
        const searchTerm = searchInput ? searchInput.value : '';
        const status = statusSelect ? statusSelect.value : '';
        console.log('Filtering payments:', { searchTerm, status });
    }, 300);
};

// Bulk payment actions
window.applyBulkPaymentAction = function() {
    const selectedPayments = document.querySelectorAll('#payments input[type="checkbox"]:checked');
    const actionSelect = document.querySelector('#payments select[class*="px-3"]');
    const action = actionSelect ? actionSelect.value : '';
    
    if (selectedPayments.length === 0) {
        showNotification('Please select at least one payment', 'warning');
        return;
    }

    if (action === 'Bulk Actions' || !action) {
        showNotification('Please select an action', 'warning');
        return;
    }

    console.log('Applying bulk action:', action, 'to', selectedPayments.length, 'payments');
    showNotification(`${action} applied to ${selectedPayments.length} payments`, 'success');
};

// Select all payments
window.toggleSelectAllPayments = function() {
    const selectAll = document.getElementById('selectAllPayments');
    const checkboxes = document.querySelectorAll('#payments tbody input[type="checkbox"]');
    
    if (selectAll) {
        checkboxes.forEach(checkbox => {
            checkbox.checked = selectAll.checked;
        });
    }
};

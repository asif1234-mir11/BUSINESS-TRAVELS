// Tour Admin Panel JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    initializeCharts();
    initializeMobileMenu();
    loadDashboardData();
    initializePackageFilters();
    
    // Add event listeners for quick actions
    document.querySelectorAll('.quick-action-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const action = this.dataset.action;
            handleQuickAction(action);
        });
    });
    
    // Add package filter listeners for select elements
    const packageSelects = document.querySelectorAll('#packages select');
    packageSelects.forEach(select => {
        select.addEventListener('change', filterPackages);
    });
    
    // Add package action listeners
    document.addEventListener('click', function(e) {
        if (e.target.closest('.package-edit-btn')) {
            const packageId = e.target.closest('.package-card').dataset.packageId;
            editPackage(packageId);
        }
        
        if (e.target.closest('.package-duplicate-btn')) {
            const packageId = e.target.closest('.package-card').dataset.packageId;
            duplicatePackage(packageId);
        }
        
        if (e.target.closest('.package-delete-btn')) {
            const packageId = e.target.closest('.package-card').dataset.packageId;
            deletePackage(packageId);
        }
        
        if (e.target.closest('.new-package-btn')) {
            createPackage();
        }
    });
});

function initializeAdminPanel() {
    showSection('dashboard');
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('data-section');
            showSection(target);
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

function showSection(sectionId) {
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => section.classList.add('hidden'));
    const targetSection = document.getElementById(sectionId);
    if (targetSection) targetSection.classList.remove('hidden');
    loadSectionData(sectionId);
}

function loadSectionData(sectionId) {
    switch(sectionId) {
        case 'dashboard':
            loadDashboardData();
            break;
        case 'bookings':
            loadBookingsData();
            break;
        case 'packages':
            loadPackagesData();
            break;
        case 'customers':
            loadCustomersData();
            break;
        case 'payments':
            loadPaymentsData();
            break;
    }
}

function initializeCharts() {
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx) {
        new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Revenue',
                    data: [12000, 19000, 15000, 25000, 22000, 30000],
                    borderColor: 'rgb(59, 130, 246)',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    const bookingsCtx = document.getElementById('bookingsChart');
    if (bookingsCtx) {
        new Chart(bookingsCtx, {
            type: 'doughnut',
            data: {
                labels: ['Confirmed', 'Pending', 'Cancelled'],
                datasets: [{
                    data: [65, 25, 10],
                    backgroundColor: [
                        'rgb(34, 197, 94)',
                        'rgb(251, 191, 36)',
                        'rgb(239, 68, 68)'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
}

function initializeEventListeners() {
    const quickActions = document.querySelectorAll('.quick-action');
    quickActions.forEach(action => {
        action.addEventListener('click', function() {
            const actionType = this.getAttribute('data-action');
            handleQuickAction(actionType);
        });
    });

    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal-close') || e.target.closest('.modal-close')) {
            closeModal(e.target);
        }
    });

    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            handleFormSubmission(this);
        });
    });
}

function handleQuickAction(actionType) {
    switch(actionType) {
        case 'new-booking':
            showModal('newBookingModal');
            break;
        case 'new-package':
            createPackage();
            break;
        case 'new-customer':
            showModal('newCustomerModal');
            break;
        case 'export-data':
            exportData();
            break;
        default:
            console.log('Unknown action:', actionType);
    }
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(element) {
    const modal = element.closest('.modal') || element.closest('[id$="Modal"]');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        document.body.style.overflow = 'auto';
    }
}

function handleFormSubmission(form) {
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Processing...';
    submitBtn.disabled = true;

                                <option value="">Select Category</option>
                                <option value="adventure">Adventure</option>
                                <option value="luxury">Luxury</option>
                                <option value="honeymoon">Honeymoon</option>
                                <option value="family">Family</option>
                                <option value="cultural">Cultural</option>
                                <option value="beach">Beach</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Destination *</label>
                            <input type="text" name="destination" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="e.g., Bali, Indonesia">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Duration (Days) *</label>
                            <input type="number" name="duration" required min="1" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="7">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Price (USD) *</label>
                            <input type="number" name="price" required min="0" step="0.01" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="1299.00">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Max Guests *</label>
                            <input type="number" name="maxGuests" required min="1" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="12">
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Short Description *</label>
                            <textarea name="description" required rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="Brief description of the package..."></textarea>
                        </div>
                        
                        <!-- Package Images -->
                        <div class="md:col-span-2">
                            <h4 class="text-lg font-semibold text-gray-900 mb-4 mt-6">Package Images</h4>
                            <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                                <i class="fas fa-cloud-upload-alt text-3xl text-gray-400 mb-2"></i>
                                <p class="text-gray-600 mb-2">Drag and drop images here, or click to select</p>
                                <input type="file" multiple accept="image/*" class="hidden" id="packageImages">
                                <button type="button" onclick="document.getElementById('packageImages').click()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                                    Select Images
                                </button>
                            </div>
                        </div>
                        
                        <!-- Itinerary -->
                        <div class="md:col-span-2">
                            <h4 class="text-lg font-semibold text-gray-900 mb-4 mt-6">Itinerary</h4>
                            <div id="itineraryContainer">
                                <div class="itinerary-day border border-gray-200 rounded-lg p-4 mb-4">
                                    <div class="flex justify-between items-center mb-3">
                                        <h5 class="font-medium text-gray-900">Day 1</h5>
                                        <button type="button" onclick="removeItineraryDay(this)" class="text-red-600 hover:text-red-800">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                    <input type="text" placeholder="Day title" class="w-full px-3 py-2 border border-gray-300 rounded-lg mb-2" name="dayTitle[]">
                                    <textarea placeholder="Day activities and description" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg" name="dayDescription[]"></textarea>
                                </div>
                            </div>
                            <button type="button" onclick="addItineraryDay()" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                                <i class="fas fa-plus mr-2"></i>Add Day
                            </button>
                        </div>
                        
                        <!-- Inclusions & Exclusions -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Inclusions</label>
                            <textarea name="inclusions" rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="What's included in the package..."></textarea>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Exclusions</label>
                            <textarea name="exclusions" rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="What's not included..."></textarea>
                        </div>
                        
                        <!-- Status -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                            <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <option value="draft">Draft</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    window.addItineraryDay = function() {
        const container = document.getElementById('itineraryContainer');
        const dayCount = container.children.length + 1;
        const dayHtml = `
            <div class="itinerary-day border border-gray-200 rounded-lg p-4 mb-4">
                <div class="flex justify-between items-center mb-3">
                    <h4 class="font-medium text-gray-900">Day ${dayCount}</h4>
                    <button type="button" onclick="removeItineraryDay(this)" class="text-red-600 hover:text-red-800">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input type="text" placeholder="Day title" class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    <input type="text" placeholder="Location" class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <textarea placeholder="Activities and description" rows="3" class="w-full mt-3 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"></textarea>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', dayHtml);
    };

    window.removeItineraryDay = function(button) {
        button.closest('.itinerary-day').remove();
        // Renumber days
        const days = document.querySelectorAll('.itinerary-day h4');
        days.forEach((day, index) => {
            day.textContent = `Day ${index + 1}`;
        });
    };

    // Package filtering with debounce
    let packageFilterTimeout;
    window.filterPackages = function() {
        clearTimeout(packageFilterTimeout);
        packageFilterTimeout = setTimeout(() => {
            const searchTerm = document.querySelector('#packages input[placeholder="Search packages..."]').value;
            console.log('Filtering packages:', searchTerm);
            // Implement actual filtering logic here
        }, 300);
    };

// Utility Functions
function showModal(title, content, size = 'max-w-2xl') {
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4';
    modal.innerHTML = `
        <div class="bg-white rounded-xl ${size} w-full max-h-[90vh] overflow-y-auto transform transition-all duration-300 scale-95 opacity-0">
            <div class="p-6 border-b border-gray-200">
                <div class="flex justify-between items-center">
                    <h3 class="text-xl font-bold text-gray-900">${title}</h3>
                    <button onclick="closeModal(this)" class="text-gray-400 hover:text-gray-600 transition-colors">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
            </div>
            <div class="p-6">
                ${content}
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Animate in
    setTimeout(() => {
        const modalContent = modal.querySelector('.bg-white');
        modalContent.style.transform = 'scale(1)';
        modalContent.style.opacity = '1';
    }, 10);
    
    return modal;
}

function closeModal(button) {
    const modal = button.closest('.fixed');
    const modalContent = modal.querySelector('.bg-white');
    
    modalContent.style.transform = 'scale(0.95)';
    modalContent.style.opacity = '0';
    
    setTimeout(() => {
        modal.remove();
    }, 300);
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 px-6 py-4 rounded-lg shadow-lg z-50 transform transition-all duration-300 ${
        type === 'success' ? 'bg-green-500 text-white' :
        type === 'error' ? 'bg-red-500 text-white' :
        type === 'warning' ? 'bg-yellow-500 text-white' :
        'bg-blue-500 text-white'
    }`;
    
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas ${
                type === 'success' ? 'fa-check-circle' :
                type === 'error' ? 'fa-exclamation-circle' :
                type === 'warning' ? 'fa-exclamation-triangle' :
                'fa-info-circle'
            } mr-2"></i>
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white hover:text-gray-200">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 10);
    
    // Remove notification after 5 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 300);
    }, 5000);
}

// Filter Functions
function applyFilters() {
    const activeSection = document.querySelector('.section:not(.hidden)');
    const sectionId = activeSection.id;
    
    switch(sectionId) {
        case 'packages':
            filterPackages();
            break;
        case 'bookings':
            filterBookings();
            break;
        case 'customers':
            filterCustomers();
            break;
        default:
            console.log('Applying filters for:', sectionId);
    }
}

function filterBookings() {
    // Booking filter logic
    console.log('Filtering bookings...');
}

function filterCustomers() {
    // Customer filter logic
    console.log('Filtering customers...');
}

// Export/Import Functions
function exportData(type) {
    console.log('Exporting data:', type);
    showNotification(`Exporting ${type} data...`, 'info');
    
    // Simulate export process
    setTimeout(() => {
        showNotification(`${type} data exported successfully!`, 'success');
    }, 2000);
}

function importData(type) {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv,.xlsx,.json';
    input.onchange = function(e) {
        const file = e.target.files[0];
        if (file) {
            console.log('Importing file:', file.name);
            showNotification(`Importing ${type} data...`, 'info');
            
            // Simulate import process
            setTimeout(() => {
                showNotification(`${type} data imported successfully!`, 'success');
            }, 2000);
        }
    };
    input.click();
}

// Utility Functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(date) {
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    }).format(new Date(date));
}

function formatDateTime(date) {
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    }).format(new Date(date));
}

function generateId() {
    return 'id_' + Math.random().toString(36).substr(2, 9);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Debounced filter function
const debouncedFilter = debounce(filterPackages, 300);

// Update search input to use debounced filtering
function initializePackageFilters() {
    const searchInput = document.querySelector('#packages input[placeholder="Search packages..."]');
    if (searchInput) {
        searchInput.addEventListener('input', debouncedFilter);
    }
}

function handleSearch(event) {
    const searchTerm = event.target.value.toLowerCase();
    console.log('Searching for:', searchTerm);
    // Implement search logic here
}

function handleFilter(event) {
    const filterValue = event.target.value;
    console.log('Filtering by:', filterValue);
    // Implement filter logic here
}

// Tour Admin Panel JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    initializeCharts();
    initializeMobileMenu();
    loadDashboardData();
});

function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.section');

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all links
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            // Hide all sections
            sections.forEach(section => section.classList.add('hidden'));
            
            // Show target section
            const targetSection = this.getAttribute('data-section');
            document.getElementById(targetSection).classList.remove('hidden');
            
            // Close mobile menu if open
            closeMobileMenu();
        });
    });
}

function initializeMobileMenu() {
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');

    sidebarToggle.addEventListener('click', function() {
        sidebar.classList.toggle('-translate-x-full');
        overlay.classList.toggle('hidden');
    });

    overlay.addEventListener('click', closeMobileMenu);
}

function closeMobileMenu() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    
    sidebar.classList.add('-translate-x-full');
    overlay.classList.add('hidden');
}

function initializeCharts() {
    // Booking Trends Chart
    const bookingTrendsCtx = document.getElementById('bookingTrendsChart');
    if (bookingTrendsCtx) {
        new Chart(bookingTrendsCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Bookings',
                    data: [120, 190, 300, 500, 200, 300, 450, 380, 420, 380, 290, 340],
                    borderColor: 'rgb(37, 99, 235)',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: 'Revenue ($K)',
                    data: [85, 120, 180, 280, 150, 200, 320, 270, 300, 260, 210, 240],
                    borderColor: 'rgb(16, 185, 129)',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    x: {
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    }
                }
            }
        });
    }

    // Popular Destinations Chart
    const destinationsCtx = document.getElementById('destinationsChart');
    if (destinationsCtx) {
        new Chart(destinationsCtx, {
            type: 'doughnut',
            data: {
                labels: ['Bali', 'Thailand', 'Europe', 'Japan', 'Maldives', 'Others'],
                datasets: [{
                    data: [25, 20, 18, 15, 12, 10],
                    backgroundColor: [
                        'rgb(37, 99, 235)',
                        'rgb(16, 185, 129)',
                        'rgb(245, 158, 11)',
                        'rgb(239, 68, 68)',
                        'rgb(139, 92, 246)',
                        'rgb(107, 114, 128)'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    }
}

function loadDashboardData() {
    // Simulate loading dashboard data
    setTimeout(() => {
        animateCounters();
    }, 500);
}

function animateCounters() {
    const counters = [
        { element: document.querySelector('.text-3xl'), target: 2847, suffix: '' },
        { element: document.querySelectorAll('.text-3xl')[1], target: 156, suffix: '' },
        { element: document.querySelectorAll('.text-3xl')[2], target: 284, suffix: 'K' },
        { element: document.querySelectorAll('.text-3xl')[3], target: 23, suffix: '' }
    ];

    counters.forEach(counter => {
        if (counter.element) {
            animateCounter(counter.element, counter.target, counter.suffix);
        }
    });
}

function animateCounter(element, target, suffix) {
    let current = 0;
    const increment = target / 50;
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        element.textContent = Math.floor(current).toLocaleString() + suffix;
    }, 30);
}

// Booking Management Functions
function viewBooking(bookingId) {
    console.log('Viewing booking:', bookingId);
    showModal('booking-details', {
        title: 'Booking Details',
        content: `Detailed information for booking ${bookingId}`
    });
}

function editBooking(bookingId) {
    console.log('Editing booking:', bookingId);
    showModal('booking-edit', {
        title: 'Edit Booking',
        content: `Edit form for booking ${bookingId}`
    });
}

function cancelBooking(bookingId) {
    if (confirm('Are you sure you want to cancel this booking?')) {
        console.log('Cancelling booking:', bookingId);
        showNotification('Booking cancelled successfully', 'success');
    }
}

// Package Management Functions
function createPackage() {
    showPackageModal();
}

function editPackage(packageId) {
    showPackageModal(packageId);
}

function deletePackage(packageId) {
    if (confirm('Are you sure you want to delete this package? This action cannot be undone.')) {
        // API call to delete package
        console.log('Deleting package:', packageId);
        showNotification('Package deleted successfully', 'success');
        // Refresh package list
        loadPackages();
    }
}

function duplicatePackage(packageId) {
    // API call to duplicate package
    console.log('Duplicating package:', packageId);
    showNotification('Package duplicated successfully', 'success');
    loadPackages();
}

function showPackageModal(packageId = null) {
    const isEdit = packageId !== null;
    const modalHtml = `
        <div id="packageModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div class="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                <div class="p-6 border-b border-gray-200">
                    <div class="flex justify-between items-center">
                        <h3 class="text-xl font-bold text-gray-900">
                            ${isEdit ? 'Edit Package' : 'Create New Package'}
                        </h3>
                        <button onclick="closePackageModal()" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                </div>
                <form id="packageForm" class="p-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Basic Information -->
                        <div class="md:col-span-2">
                            <h4 class="text-lg font-semibold text-gray-900 mb-4">Basic Information</h4>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Package Name *</label>
                            <input type="text" name="name" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="e.g., Bali Adventure Package">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Category *</label>
                            <select name="category" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <option value="">Select Category</option>
                                <option value="adventure">Adventure</option>
                                <option value="luxury">Luxury</option>
                                <option value="honeymoon">Honeymoon</option>
                                <option value="family">Family</option>
                                <option value="cultural">Cultural</option>
                                <option value="beach">Beach</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Destination *</label>
                            <input type="text" name="destination" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="e.g., Bali, Indonesia">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Duration (Days) *</label>
                            <input type="number" name="duration" required min="1" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="7">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Price (USD) *</label>
                            <input type="number" name="price" required min="0" step="0.01" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="1299.00">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Max Guests *</label>
                            <input type="number" name="maxGuests" required min="1" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="12">
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Short Description *</label>
                            <textarea name="description" required rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="Brief description of the package..."></textarea>
                        </div>
                        
                        <!-- Package Images -->
                        <div class="md:col-span-2">
                            <h4 class="text-lg font-semibold text-gray-900 mb-4 mt-6">Package Images</h4>
                            <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                                <i class="fas fa-cloud-upload-alt text-3xl text-gray-400 mb-2"></i>
                                <p class="text-gray-600 mb-2">Drag and drop images here, or click to select</p>
                                <input type="file" multiple accept="image/*" class="hidden" id="packageImages">
                                <button type="button" onclick="document.getElementById('packageImages').click()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                                    Select Images
                                </button>
                            </div>
                        </div>
                        
                        <!-- Itinerary -->
                        <div class="md:col-span-2">
                            <h4 class="text-lg font-semibold text-gray-900 mb-4 mt-6">Itinerary</h4>
                            <div id="itineraryContainer">
                                <div class="itinerary-day border border-gray-200 rounded-lg p-4 mb-4">
                                    <div class="flex justify-between items-center mb-3">
                                        <h5 class="font-medium text-gray-900">Day 1</h5>
                                        <button type="button" onclick="removeItineraryDay(this)" class="text-red-600 hover:text-red-800">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                    <input type="text" placeholder="Day title" class="w-full px-3 py-2 border border-gray-300 rounded-lg mb-2" name="dayTitle[]">
                                    <textarea placeholder="Day activities and description" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg" name="dayDescription[]"></textarea>
                                </div>
                            </div>
                            <button type="button" onclick="addItineraryDay()" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                                <i class="fas fa-plus mr-2"></i>Add Day
                            </button>
                        </div>
                        
                        <!-- Inclusions & Exclusions -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Inclusions</label>
                            <textarea name="inclusions" rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="What's included in the package..."></textarea>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Exclusions</label>
                            <textarea name="exclusions" rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="What's not included..."></textarea>
                        </div>
                        
                        <!-- Status -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                            <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <option value="draft">Draft</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-4 mt-8 pt-6 border-t border-gray-200">
                        <button type="button" onclick="closePackageModal()" class="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                            Cancel
                        </button>
                        <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                            ${isEdit ? 'Update Package' : 'Create Package'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    // Handle form submission
    document.getElementById('packageForm').addEventListener('submit', function(e) {
        e.preventDefault();
        savePackage(isEdit, packageId);
    });
}

function closePackageModal() {
    const modal = document.getElementById('packageModal');
    if (modal) {
        modal.remove();
    }
}

function addItineraryDay() {
    const container = document.getElementById('itineraryContainer');
    const dayCount = container.children.length + 1;
    
    const dayHtml = `
        <div class="itinerary-day border border-gray-200 rounded-lg p-4 mb-4">
            <div class="flex justify-between items-center mb-3">
                <h5 class="font-medium text-gray-900">Day ${dayCount}</h5>
                <button type="button" onclick="removeItineraryDay(this)" class="text-red-600 hover:text-red-800">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            <input type="text" placeholder="Day title" class="w-full px-3 py-2 border border-gray-300 rounded-lg mb-2" name="dayTitle[]">
            <textarea placeholder="Day activities and description" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg" name="dayDescription[]"></textarea>
        </div>
    `;
    
    container.insertAdjacentHTML('beforeend', dayHtml);
}

function removeItineraryDay(button) {
    const dayElement = button.closest('.itinerary-day');
    dayElement.remove();
    
    // Renumber remaining days
    const container = document.getElementById('itineraryContainer');
    const days = container.querySelectorAll('.itinerary-day');
    days.forEach((day, index) => {
        day.querySelector('h5').textContent = `Day ${index + 1}`;
    });
}

function savePackage(isEdit, packageId) {
    const formData = new FormData(document.getElementById('packageForm'));
    
    // Here you would make an API call to save the package
    console.log(isEdit ? 'Updating package:' : 'Creating package:', Object.fromEntries(formData));
    
    showNotification(isEdit ? 'Package updated successfully!' : 'Package created successfully!', 'success');
    closePackageModal();
    loadPackages();
}

function loadPackages() {
    // API call to load packages
    console.log('Loading packages...');
    // This would refresh the packages grid
}

// Package filtering
function filterPackages() {
    const searchTerm = document.querySelector('input[placeholder="Search packages..."]').value.toLowerCase();
    const category = document.querySelector('select').value;
    
    // Filter logic would go here
    console.log('Filtering packages:', { searchTerm, category });
}

// Initialize charts when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
    
    // Add event listeners for quick actions
    document.querySelectorAll('.quick-action-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const action = this.dataset.action;
            handleQuickAction(action);
        });
    });
    
    // Initialize package filters
    initializePackageFilters();
    
    // Add package filter listeners for select elements
    const packageSelects = document.querySelectorAll('#packages select');
    packageSelects.forEach(select => {
        select.addEventListener('change', filterPackages);
    });
    
    // Add package action listeners
    document.addEventListener('click', function(e) {
        if (e.target.closest('.package-edit-btn')) {
            const packageId = e.target.closest('.package-card').dataset.packageId;
            editPackage(packageId);
        }
        
        if (e.target.closest('.package-duplicate-btn')) {
            const packageId = e.target.closest('.package-card').dataset.packageId;
            duplicatePackage(packageId);
        }
        
        if (e.target.closest('.package-delete-btn')) {
            const packageId = e.target.closest('.package-card').dataset.packageId;
            deletePackage(packageId);
        }
        
        if (e.target.closest('.new-package-btn')) {
            createPackage();
        }
    });
}

// Utility Functions
function showModal(title, content, size = 'max-w-2xl') {
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4';
    modal.innerHTML = `
        <div class="bg-white rounded-xl ${size} w-full max-h-[90vh] overflow-y-auto transform transition-all duration-300 scale-95 opacity-0">
            <div class="p-6 border-b border-gray-200">
                <div class="flex justify-between items-center">
                    <h3 class="text-xl font-bold text-gray-900">${title}</h3>
                    <button onclick="closeModal(this)" class="text-gray-400 hover:text-gray-600 transition-colors">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
            </div>
            <div class="p-6">
                ${content}
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Animate in
    setTimeout(() => {
        const modalContent = modal.querySelector('.bg-white');
        modalContent.style.transform = 'scale(1)';
        modalContent.style.opacity = '1';
    }, 10);
    
    return modal;
}

function closeModal(button) {
    const modal = button.closest('.fixed');
    const modalContent = modal.querySelector('.bg-white');
    
    modalContent.style.transform = 'scale(0.95)';
    modalContent.style.opacity = '0';
    
    setTimeout(() => {
        modal.remove();
    }, 300);
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 px-6 py-4 rounded-lg shadow-lg z-50 transform transition-all duration-300 ${
        type === 'success' ? 'bg-green-500 text-white' :
        type === 'error' ? 'bg-red-500 text-white' :
        type === 'warning' ? 'bg-yellow-500 text-white' :
        'bg-blue-500 text-white'
    }`;
    
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas ${
                type === 'success' ? 'fa-check-circle' :
                type === 'error' ? 'fa-exclamation-circle' :
                type === 'warning' ? 'fa-exclamation-triangle' :
                'fa-info-circle'
            } mr-2"></i>
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white hover:text-gray-200">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 10);
    
    // Remove notification after 5 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 300);
    }, 5000);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(date) {
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    }).format(new Date(date));
}

function formatDateTime(date) {
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    }).format(new Date(date));
}

function generateId() {
    return 'id_' + Math.random().toString(36).substr(2, 9);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Debounced filter function
const debouncedFilter = debounce(filterPackages, 300);

// Update search input to use debounced filtering
function initializePackageFilters() {
    const searchInput = document.querySelector('#packages input[placeholder="Search packages..."]');
    if (searchInput) {
        searchInput.addEventListener('input', debouncedFilter);
    }
}

function handleSearch(event) {
    const searchTerm = event.target.value.toLowerCase();
    console.log('Searching for:', searchTerm);
    // Implement search logic here
}

function handleFilter(event) {
    const filterValue = event.target.value;
    console.log('Filtering by:', filterValue);
    // Implement filter logic here
}

// Initialize filters when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeFilters();
});

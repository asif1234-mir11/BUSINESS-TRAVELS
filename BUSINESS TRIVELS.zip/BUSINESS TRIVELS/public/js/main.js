// Business Travels - Main JavaScript File

class BusinessTravels {
    constructor() {
        this.currentUser = null;
        this.searchResults = [];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupDateDefaults();
        this.setupMobileMenu();
    }

    setupEventListeners() {
        // Tab switching
        document.getElementById('flightTab')?.addEventListener('click', () => this.switchTab('flight'));
        document.getElementById('hotelTab')?.addEventListener('click', () => this.switchTab('hotel'));
        document.getElementById('packageTab')?.addEventListener('click', () => this.switchTab('package'));

        // Search buttons
        document.getElementById('searchFlights')?.addEventListener('click', () => this.searchFlights());
        document.getElementById('searchHotels')?.addEventListener('click', () => this.searchHotels());
        document.getElementById('searchPackages')?.addEventListener('click', () => this.searchPackages());

        // Auth buttons
        document.getElementById('loginBtn')?.addEventListener('click', () => this.showLoginModal());
        document.getElementById('signupBtn')?.addEventListener('click', () => this.showSignupModal());

        // Mobile menu
        document.getElementById('mobileMenuBtn')?.addEventListener('click', () => this.toggleMobileMenu());

        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    }

    setupDateDefaults() {
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        const nextWeek = new Date(today);
        nextWeek.setDate(nextWeek.getDate() + 7);

        // Set default dates
        const departDate = document.getElementById('departDate');
        const returnDate = document.getElementById('returnDate');
        const checkinDate = document.getElementById('checkinDate');
        const checkoutDate = document.getElementById('checkoutDate');

        if (departDate) departDate.value = this.formatDate(tomorrow);
        if (returnDate) returnDate.value = this.formatDate(nextWeek);
        if (checkinDate) checkinDate.value = this.formatDate(tomorrow);
        if (checkoutDate) checkoutDate.value = this.formatDate(nextWeek);
    }

    formatDate(date) {
        return date.toISOString().split('T')[0];
    }

    setupMobileMenu() {
        const mobileMenu = document.getElementById('mobileMenu');
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        
        if (mobileMenuBtn && mobileMenu) {
            mobileMenuBtn.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
            });
        }
    }

    switchTab(tabType) {
        // Hide all search forms
        document.getElementById('flightSearch')?.classList.add('hidden');
        document.getElementById('hotelSearch')?.classList.add('hidden');
        document.getElementById('packageSearch')?.classList.add('hidden');

        // Remove active class from all tabs
        document.querySelectorAll('[id$="Tab"]').forEach(tab => {
            tab.classList.remove('bg-primary-600', 'text-white');
            tab.classList.add('text-gray-600', 'hover:text-gray-900');
        });

        // Show selected form and activate tab
        const activeTab = document.getElementById(`${tabType}Tab`);
        const activeForm = document.getElementById(`${tabType}Search`);
        
        if (activeTab && activeForm) {
            activeTab.classList.add('bg-primary-600', 'text-white');
            activeTab.classList.remove('text-gray-600', 'hover:text-gray-900');
            activeForm.classList.remove('hidden');
        }
    }

    async searchFlights() {
        const fromCity = document.getElementById('fromCity')?.value;
        const toCity = document.getElementById('toCity')?.value;
        const departDate = document.getElementById('departDate')?.value;
        const returnDate = document.getElementById('returnDate')?.value;
        const passengers = document.getElementById('passengers')?.value;
        const flightClass = document.getElementById('class')?.value;

        if (!fromCity || !toCity || !departDate) {
            this.showNotification('Please fill in all required fields', 'error');
            return;
        }

        this.showLoadingState('searchFlights');

        try {
            // Simulate API call
            await this.delay(2000);
            
            const mockResults = this.generateMockFlightResults(fromCity, toCity, departDate, returnDate);
            this.displayFlightResults(mockResults);
            this.showNotification('Flight search completed!', 'success');
        } catch (error) {
            this.showNotification('Error searching flights. Please try again.', 'error');
        } finally {
            this.hideLoadingState('searchFlights');
        }
    }

    async searchHotels() {
        const destination = document.getElementById('hotelDestination')?.value;
        const checkinDate = document.getElementById('checkinDate')?.value;
        const checkoutDate = document.getElementById('checkoutDate')?.value;
        const rooms = document.getElementById('rooms')?.value;
        const guests = document.getElementById('guests')?.value;

        if (!destination || !checkinDate || !checkoutDate) {
            this.showNotification('Please fill in all required fields', 'error');
            return;
        }

        this.showLoadingState('searchHotels');

        try {
            await this.delay(2000);
            
            const mockResults = this.generateMockHotelResults(destination, checkinDate, checkoutDate);
            this.displayHotelResults(mockResults);
            this.showNotification('Hotel search completed!', 'success');
        } catch (error) {
            this.showNotification('Error searching hotels. Please try again.', 'error');
        } finally {
            this.hideLoadingState('searchHotels');
        }
    }

    async searchPackages() {
        const destination = document.getElementById('packageDestination')?.value;
        const duration = document.getElementById('duration')?.value;
        const budget = document.getElementById('budget')?.value;

        if (!destination) {
            this.showNotification('Please enter a destination', 'error');
            return;
        }

        this.showLoadingState('searchPackages');

        try {
            await this.delay(2000);
            
            const mockResults = this.generateMockPackageResults(destination, duration, budget);
            this.displayPackageResults(mockResults);
            this.showNotification('Package search completed!', 'success');
        } catch (error) {
            this.showNotification('Error searching packages. Please try again.', 'error');
        } finally {
            this.hideLoadingState('searchPackages');
        }
    }

    generateMockFlightResults(from, to, depart, returnDate) {
        const airlines = ['Delta', 'American Airlines', 'United', 'Southwest', 'JetBlue'];
        const results = [];

        for (let i = 0; i < 5; i++) {
            results.push({
                id: `flight-${i}`,
                airline: airlines[Math.floor(Math.random() * airlines.length)],
                from,
                to,
                departTime: `${Math.floor(Math.random() * 12) + 1}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')} ${Math.random() > 0.5 ? 'AM' : 'PM'}`,
                arriveTime: `${Math.floor(Math.random() * 12) + 1}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')} ${Math.random() > 0.5 ? 'AM' : 'PM'}`,
                duration: `${Math.floor(Math.random() * 8) + 2}h ${Math.floor(Math.random() * 60)}m`,
                price: Math.floor(Math.random() * 800) + 200,
                stops: Math.floor(Math.random() * 3)
            });
        }

        return results;
    }

    generateMockHotelResults(destination, checkin, checkout) {
        const hotelNames = ['Grand Plaza Hotel', 'Luxury Resort & Spa', 'Business Center Inn', 'Comfort Suites', 'Royal Palace Hotel'];
        const results = [];

        for (let i = 0; i < 5; i++) {
            results.push({
                id: `hotel-${i}`,
                name: hotelNames[Math.floor(Math.random() * hotelNames.length)],
                destination,
                rating: (Math.random() * 2 + 3).toFixed(1),
                price: Math.floor(Math.random() * 300) + 100,
                amenities: ['Free WiFi', 'Pool', 'Gym', 'Restaurant', 'Spa'].slice(0, Math.floor(Math.random() * 3) + 2),
                image: `https://via.placeholder.com/300x200?text=Hotel+${i+1}`
            });
        }

        return results;
    }

    generateMockPackageResults(destination, duration, budget) {
        const packageTypes = ['Adventure Package', 'Luxury Getaway', 'Cultural Experience', 'Beach Paradise', 'City Explorer'];
        const results = [];

        for (let i = 0; i < 4; i++) {
            results.push({
                id: `package-${i}`,
                name: packageTypes[Math.floor(Math.random() * packageTypes.length)],
                destination,
                duration,
                price: Math.floor(Math.random() * 2000) + 500,
                includes: ['Round-trip flights', 'Hotel accommodation', 'Daily breakfast', 'Airport transfers'],
                rating: (Math.random() * 2 + 3).toFixed(1),
                image: `https://via.placeholder.com/400x250?text=Package+${i+1}`
            });
        }

        return results;
    }

    displayFlightResults(results) {
        this.createResultsSection('Flight Results', results.map(flight => `
            <div class="card mb-4 hover:shadow-xl transition-shadow duration-300">
                <div class="flex justify-between items-center">
                    <div class="flex-1">
                        <div class="flex items-center mb-2">
                            <h3 class="text-lg font-semibold text-gray-900">${flight.airline}</h3>
                            <span class="ml-2 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">${flight.stops === 0 ? 'Direct' : flight.stops + ' stop(s)'}</span>
                        </div>
                        <div class="grid grid-cols-3 gap-4 text-sm text-gray-600">
                            <div>
                                <p class="font-medium">${flight.from}</p>
                                <p class="text-lg font-bold text-gray-900">${flight.departTime}</p>
                            </div>
                            <div class="text-center">
                                <p class="text-xs">${flight.duration}</p>
                                <div class="flex items-center justify-center my-1">
                                    <div class="h-px bg-gray-300 flex-1"></div>
                                    <i class="fas fa-plane text-gray-400 mx-2"></i>
                                    <div class="h-px bg-gray-300 flex-1"></div>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="font-medium">${flight.to}</p>
                                <p class="text-lg font-bold text-gray-900">${flight.arriveTime}</p>
                            </div>
                        </div>
                    </div>
                    <div class="ml-6 text-right">
                        <p class="text-2xl font-bold text-primary-600">$${flight.price}</p>
                        <button class="btn-primary mt-2" onclick="app.bookFlight('${flight.id}')">
                            Select Flight
                        </button>
                    </div>
                </div>
            </div>
        `).join(''));
    }

    displayHotelResults(results) {
        this.createResultsSection('Hotel Results', results.map(hotel => `
            <div class="card mb-4 hover:shadow-xl transition-shadow duration-300">
                <div class="flex">
                    <img src="${hotel.image}" alt="${hotel.name}" class="w-32 h-24 object-cover rounded-lg mr-4">
                    <div class="flex-1">
                        <div class="flex justify-between items-start">
                            <div>
                                <h3 class="text-lg font-semibold text-gray-900">${hotel.name}</h3>
                                <div class="flex items-center mb-2">
                                    <div class="flex text-yellow-400">
                                        ${'★'.repeat(Math.floor(hotel.rating))}${'☆'.repeat(5 - Math.floor(hotel.rating))}
                                    </div>
                                    <span class="ml-2 text-sm text-gray-600">${hotel.rating}/5</span>
                                </div>
                                <div class="flex flex-wrap gap-1">
                                    ${hotel.amenities.map(amenity => `<span class="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded">${amenity}</span>`).join('')}
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="text-2xl font-bold text-primary-600">$${hotel.price}</p>
                                <p class="text-sm text-gray-600">per night</p>
                                <button class="btn-primary mt-2" onclick="app.bookHotel('${hotel.id}')">
                                    Book Now
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `).join(''));
    }

    displayPackageResults(results) {
        this.createResultsSection('Package Results', `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                ${results.map(pkg => `
                    <div class="card hover:shadow-xl transition-shadow duration-300">
                        <img src="${pkg.image}" alt="${pkg.name}" class="w-full h-48 object-cover rounded-lg mb-4">
                        <h3 class="text-xl font-semibold text-gray-900 mb-2">${pkg.name}</h3>
                        <div class="flex items-center mb-3">
                            <div class="flex text-yellow-400">
                                ${'★'.repeat(Math.floor(pkg.rating))}${'☆'.repeat(5 - Math.floor(pkg.rating))}
                            </div>
                            <span class="ml-2 text-sm text-gray-600">${pkg.rating}/5</span>
                        </div>
                        <div class="mb-4">
                            <h4 class="font-medium text-gray-900 mb-2">Package Includes:</h4>
                            <ul class="text-sm text-gray-600 space-y-1">
                                ${pkg.includes.map(item => `<li><i class="fas fa-check text-green-500 mr-2"></i>${item}</li>`).join('')}
                            </ul>
                        </div>
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="text-2xl font-bold text-primary-600">$${pkg.price}</p>
                                <p class="text-sm text-gray-600">${pkg.duration}</p>
                            </div>
                            <button class="btn-primary" onclick="app.bookPackage('${pkg.id}')">
                                Book Package
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `);
    }

    createResultsSection(title, content) {
        // Remove existing results
        const existingResults = document.getElementById('searchResults');
        if (existingResults) {
            existingResults.remove();
        }

        // Create new results section
        const resultsSection = document.createElement('section');
        resultsSection.id = 'searchResults';
        resultsSection.className = 'py-12 bg-gray-50';
        resultsSection.innerHTML = `
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <h2 class="text-3xl font-bold text-gray-900 mb-8">${title}</h2>
                <div class="results-container">
                    ${content}
                </div>
            </div>
        `;

        // Insert after the search section
        const searchSection = document.querySelector('section:has(.search-form)').parentElement;
        searchSection.insertAdjacentElement('afterend', resultsSection);

        // Scroll to results
        resultsSection.scrollIntoView({ behavior: 'smooth' });
    }

    bookFlight(flightId) {
        this.showNotification('Flight booking feature coming soon!', 'info');
    }

    bookHotel(hotelId) {
        this.showNotification('Hotel booking feature coming soon!', 'info');
    }

    bookPackage(packageId) {
        this.showNotification('Package booking feature coming soon!', 'info');
    }

    showLoginModal() {
        this.showNotification('Login feature coming soon!', 'info');
    }

    showSignupModal() {
        this.showNotification('Sign up feature coming soon!', 'info');
    }

    showLoadingState(buttonId) {
        const button = document.getElementById(buttonId);
        if (button) {
            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Searching...';
        }
    }

    hideLoadingState(buttonId) {
        const button = document.getElementById(buttonId);
        if (button) {
            button.disabled = false;
            const originalText = buttonId.includes('flight') ? 'Search Flights' : 
                               buttonId.includes('hotel') ? 'Search Hotels' : 'Find Packages';
            button.innerHTML = `<i class="fas fa-search mr-2"></i>${originalText}`;
        }
    }

    showNotification(message, type = 'info') {
        // Remove existing notifications
        const existingNotifications = document.querySelectorAll('.notification');
        existingNotifications.forEach(notification => notification.remove());

        const notification = document.createElement('div');
        notification.className = `notification fixed top-4 right-4 z-50 px-6 py-4 rounded-lg shadow-lg max-w-sm transform transition-all duration-300 translate-x-full`;
        
        const colors = {
            success: 'bg-green-500 text-white',
            error: 'bg-red-500 text-white',
            info: 'bg-blue-500 text-white',
            warning: 'bg-yellow-500 text-black'
        };

        notification.className += ` ${colors[type] || colors.info}`;
        notification.innerHTML = `
            <div class="flex items-center justify-between">
                <span>${message}</span>
                <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-lg">&times;</button>
            </div>
        `;

        document.body.appendChild(notification);

        // Animate in
        setTimeout(() => {
            notification.classList.remove('translate-x-full');
        }, 100);

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.classList.add('translate-x-full');
                setTimeout(() => notification.remove(), 300);
            }
        }, 5000);
    }

    toggleMobileMenu() {
        const mobileMenu = document.getElementById('mobileMenu');
        if (mobileMenu) {
            mobileMenu.classList.toggle('hidden');
        }
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new BusinessTravels();
});

// Add some additional interactive features
document.addEventListener('DOMContentLoaded', () => {
    // Animate elements on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in');
            }
        });
    }, observerOptions);

    // Observe cards and sections
    document.querySelectorAll('.card, section').forEach(el => {
        observer.observe(el);
    });

    // Add scroll effect to navigation
    window.addEventListener('scroll', () => {
        const nav = document.querySelector('nav');
        if (window.scrollY > 100) {
            nav.classList.add('shadow-lg');
        } else {
            nav.classList.remove('shadow-lg');
        }
    });
});

// Add CSS animation class
const style = document.createElement('style');
style.textContent = `
    .animate-fade-in {
        animation: fadeIn 0.6s ease-in-out;
    }
    
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .search-form {
        transition: all 0.3s ease-in-out;
    }
`;
document.head.appendChild(style);
